import platform
import time
from typing import Optional

import discord
from discord.ext import commands

import config
from utils import helpers


CATEGORY_META = {
    "Protection": ("🛡️", "AntiNuke, whitelist and server protection"),
    "Moderation": ("🔨", "Member and channel moderation tools"),
    "AutoMod": ("🤖", "Automatic message safety and filters"),
    "Music": ("🎵", "Play, queue and control music"),
    "Voice": ("🔊", "Temporary voice rooms and room controls"),
    "Welcome": ("👋", "Welcome messages and autoroles"),
    "Logs": ("📋", "Server event logging setup"),
    "Community": ("🌟", "Tickets, ranks, polls and suggestions"),
    "Utility": ("🧰", "Bot, server and member information"),
}
COG_CATEGORY = {
    "AntiNuke": "Protection",
    "Moderation": "Moderation",
    "AutoMod": "AutoMod",
    "Music": "Music",
    "TempVC": "Voice",
    "Welcome": "Welcome",
    "Logs": "Logs",
    "Community": "Community",
    "Utility": "Utility",
}
PAGE_SIZE = 8


def _commands_for_category(bot, category):
    found = []
    for command in bot.walk_commands():
        if command.hidden or not command.cog:
            continue
        mapped = COG_CATEGORY.get(command.cog.qualified_name, command.cog.qualified_name)
        if mapped != category:
            continue
        # A group with subcommands is represented by its actionable children.
        if isinstance(command, commands.Group) and command.commands:
            continue
        found.append(command)
    return sorted(found, key=lambda c: c.qualified_name)


def _command_line(command):
    description = (command.description or command.short_doc or "No description available.").strip()
    description = description.replace("\n", " ")[:100]
    return f"`{config.PREFIX}{command.qualified_name}`  ·  `/{command.qualified_name}`\n{description}"


class HelpCategorySelect(discord.ui.Select):
    def __init__(self, view):
        self.help_view = view
        options = [discord.SelectOption(label="Overview", value="__overview__", emoji="🏠",
                                        description="Show Riyox help center home")]
        for category, (emoji, description) in CATEGORY_META.items():
            options.append(discord.SelectOption(label=category, value=category, emoji=emoji,
                                                description=description[:100]))
        options.append(discord.SelectOption(label="Premium", value="__premium__", emoji="💎",
                                            description="Explore optional premium feature ideas"))
        super().__init__(placeholder="Choose a command category…", min_values=1, max_values=1,
                         options=options, row=0)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.help_view.requester_id:
            return await interaction.response.send_message("Open your own help panel with `&help` or `/help`.", ephemeral=True)
        self.help_view.category = self.values[0]
        self.help_view.page = 0
        await interaction.response.edit_message(embed=self.help_view.make_embed(), view=self.help_view)


class HelpCenterView(discord.ui.View):
    def __init__(self, bot, requester_id):
        super().__init__(timeout=300)
        self.bot = bot
        self.requester_id = requester_id
        self.category = "__overview__"
        self.page = 0
        self.add_item(HelpCategorySelect(self))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.requester_id:
            await interaction.response.send_message(
                "This help panel belongs to another user. Run `&help` or `/help` to open your own.",
                ephemeral=True,
            )
            return False
        return True

    def make_embed(self):
        if self.category == "__premium__":
            e = helpers.embed("💎 Riyox Premium", "An optional feature showcase for future Riyox upgrades.")
            e.add_field(name="🎵 Music+", value="Saved playlists, queue presets and per-server audio preferences.", inline=False)
            e.add_field(name="🛡️ Protection+", value="More detailed security reports, configurable alert profiles and recovery summaries.", inline=False)
            e.add_field(name="🌟 Community+", value="Extra welcome layouts, level rewards and community themes.", inline=False)
            e.add_field(name="🔐 Availability", value="These are feature ideas, not an active paid subscription. No payment is collected and core moderation/safety tools remain available without payment.", inline=False)
            e.set_footer(text="Riyox • Premium feature showcase")
            return e

        if self.category == "__overview__":
            total = sum(len(_commands_for_category(self.bot, c)) for c in CATEGORY_META)
            e = helpers.embed("💜 Riyox • Help Center", "Choose a category from the dropdown below to explore commands.")
            e.add_field(name="✨ Command access", value=f"Prefix: `{config.PREFIX}command`\nSlash: `/command`", inline=True)
            e.add_field(name="📚 Categories", value=f"{len(CATEGORY_META)} command categories", inline=True)
            e.add_field(name="⚡ Commands", value=f"{total} available commands", inline=True)
            for category, (emoji, description) in CATEGORY_META.items():
                count = len(_commands_for_category(self.bot, category))
                e.add_field(name=f"{emoji} {category} · {count}", value=description, inline=True)
            e.add_field(name="💎 Premium", value="Choose Premium to explore optional feature ideas. Core safety tools stay free.", inline=False)
            e.set_footer(text="Select a category • Use buttons to navigate • Riyox")
            return e

        commands_list = _commands_for_category(self.bot, self.category)
        pages = max(1, (len(commands_list) + PAGE_SIZE - 1) // PAGE_SIZE)
        self.page = min(self.page, pages - 1)
        start = self.page * PAGE_SIZE
        current = commands_list[start:start + PAGE_SIZE]
        emoji, description = CATEGORY_META[self.category]
        e = helpers.embed(f"{emoji} Riyox Help • {self.category}", description)
        if current:
            for command in current:
                e.add_field(name=f"{config.PREFIX}{command.qualified_name}  |  /{command.qualified_name}",
                            value=(command.description or command.short_doc or "No description available.")[:180],
                            inline=False)
        else:
            e.description = description + "\n\nNo commands are loaded in this category yet."
        e.set_footer(text=f"Page {self.page + 1}/{pages} • {len(commands_list)} commands • Prefix & Slash supported")
        return e

    @discord.ui.button(label="Home", emoji="🏠", style=discord.ButtonStyle.secondary, row=1)
    async def home(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.category = "__overview__"
        self.page = 0
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    @discord.ui.button(label="Previous", emoji="◀️", style=discord.ButtonStyle.primary, row=1)
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page = max(0, self.page - 1)
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    @discord.ui.button(label="Next", emoji="▶️", style=discord.ButtonStyle.primary, row=1)
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
        commands_list = _commands_for_category(self.bot, self.category) if self.category in CATEGORY_META else []
        pages = max(1, (len(commands_list) + PAGE_SIZE - 1) // PAGE_SIZE)
        self.page = min(pages - 1, self.page + 1)
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    @discord.ui.button(label="Premium", emoji="💎", style=discord.ButtonStyle.success, row=1)
    async def premium(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.category = "__premium__"
        self.page = 0
        await interaction.response.edit_message(embed=self.make_embed(), view=self)

    @discord.ui.button(label="Close", emoji="✖️", style=discord.ButtonStyle.danger, row=1)
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(content="Riyox Help Center closed.", embed=None, view=self)
        self.stop()


class Utility(commands.Cog, name="Utility"):
    """Help, info and small tools."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Open the interactive Riyox help center")
    async def help_cmd(self, ctx):
        view = HelpCenterView(self.bot, ctx.author.id)
        await ctx.send(embed=view.make_embed(), view=view)

    @commands.hybrid_command(name="ping", description="Check the bot's latency")
    async def ping(self, ctx):
        await ctx.send(embed=helpers.ok(f"Pong! `{round(self.bot.latency * 1000)}ms`"))

    @commands.hybrid_command(name="botinfo", description="Bot statistics")
    async def botinfo(self, ctx):
        uptime = int(time.time() - self.bot.started_at)
        days, rest = divmod(uptime, 86400)
        hours, rest = divmod(rest, 3600)
        minutes = rest // 60
        e = helpers.embed("🤖 Bot info")
        e.add_field(name="Servers", value=str(len(self.bot.guilds)))
        e.add_field(name="Users", value=str(sum(g.member_count or 0 for g in self.bot.guilds)))
        e.add_field(name="Uptime", value=f"{days}d {hours}h {minutes}m")
        e.add_field(name="Python", value=platform.python_version())
        e.add_field(name="discord.py", value=discord.__version__)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="invite", description="Get the link to add this bot to a server")
    async def invite(self, ctx):
        url = discord.utils.oauth_url(
            self.bot.user.id,
            permissions=discord.Permissions(administrator=True),
            scopes=("bot", "applications.commands"),
        )
        await ctx.send(embed=helpers.embed("Invite me", f"[Click here to add the bot]({url})"))

    @commands.hybrid_command(name="serverinfo", description="Information about this server")
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        e = helpers.embed(g.name)
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>")
        e.add_field(name="Members", value=str(g.member_count))
        e.add_field(name="Channels", value=str(len(g.channels)))
        e.add_field(name="Roles", value=str(len(g.roles)))
        e.add_field(name="Boosts", value=f"{g.premium_subscription_count} (level {g.premium_tier})")
        e.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:D>")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="userinfo", description="Information about a member")
    @commands.guild_only()
    async def userinfo(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        e = helpers.embed(str(member), color=member.color.value or config.EMBED_COLOR)
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="ID", value=str(member.id))
        e.add_field(name="Created", value=f"<t:{int(member.created_at.timestamp())}:R>")
        if member.joined_at:
            e.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>")
        roles = [r.mention for r in reversed(member.roles) if not r.is_default()]
        e.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:15]) or "None", inline=False)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="avatar", description="Show someone's avatar")
    async def avatar(self, ctx, user: Optional[discord.User] = None):
        user = user or ctx.author
        e = helpers.embed(f"{user.display_name}'s avatar")
        e.set_image(url=user.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="sync", hidden=True)
    @commands.is_owner()
    async def sync(self, ctx):
        """Owner only: re-sync slash commands."""
        synced = await self.bot.tree.sync()
        await ctx.send(embed=helpers.ok(f"Synced {len(synced)} slash commands."))


async def setup(bot):
    await bot.add_cog(Utility(bot))
