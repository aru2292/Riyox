"""Tiny web server so hosts that need an open port (and uptime pingers) stay happy."""
from aiohttp import web


async def start(port):
    app = web.Application()

    async def index(request):
        return web.Response(text="Bot is running.")

    app.router.add_get("/", index)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
