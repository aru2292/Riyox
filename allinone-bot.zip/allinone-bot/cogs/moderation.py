import time
from datetime import timedelta
from typing import Optional

import discord
from discord.ext import commands

from utils import helpers


class Moderation(commands.Cog, name="Moderation"):
    """Kick, ban, timeout, warnings, purge, lock and more."""

    def __init__(self, bot):
        self.bot = bot

    async def _log(self, ctx, action, target, reason):
        e = discord.Embed(
            title=f"Moderation: {action}",
            color=helpers.ORANGE,
            timestamp=discord.utils.utcnow(),
        )
        e.add_field(name="User", value=f"{target} (`{target.id}`)")
        e.add_field(name="Moderator", value=ctx.author.mention)
        e.add_field(name="Reason", value=reason or "No reason given", inline=False)
        await helpers.send_log(self.bot, ctx.guild, e)

    async def _dm(self, member, text):
        try:
            await member.send(text)
        except discord.HTTPException:
            pass

    # --------------------------------------------------------------- kick / ban
    @commands.hybrid_command(name="kick", description="Kick a member from the server")
    @commands.guild_only()
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: Optional[str] = None):
        problem = helpers.can_moderate(ctx, member)
        if problem:
            return await ctx.send(embed=helpers.err(problem), ephemeral=True)
        await self._dm(member, f"You were kicked from **{ctx.guild.name}**. Reason: {reason or 'none'}")
        await member.kick(reason=f"{ctx.author}: {reason or 'No reason'}")
        await ctx.send(embed=helpers.ok(f"Kicked **{member}**. Reason: {reason or 'none'}"))
        await self._log(ctx, "Kick", member, reason)

    @commands.hybrid_command(name="ban", description="Ban a user (works even if they left)")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def ban(self, ctx, user: discord.User, *, reason: Optional[str] = None):
        member = ctx.guild.get_member(user.id)
        if member is not None:
            problem = helpers.can_moderate(ctx, member)
            if problem:
                return await ctx.send(embed=helpers.err(problem), ephemeral=True)
            await self._dm(member, f"You were banned from **{ctx.guild.name}**. Reason: {reason or 'none'}")
        await ctx.guild.ban(user, reason=f"{ctx.author}: {reason or 'No reason'}", delete_message_seconds=0)
        await ctx.send(embed=helpers.ok(f"Banned **{user}**. Reason: {reason or 'none'}"))
        await self._log(ctx, "Ban", user, reason)

    @commands.hybrid_command(name="unban", description="Unban a user by ID or mention")
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def unban(self, ctx, user: discord.User, *, reason: Optional[str] = None):
        try:
            await ctx.guild.unban(user, reason=f"{ctx.author}: {reason or 'No reason'}")
        except discord.NotFound:
            return await ctx.send(embed=helpers.err("That user isn't banned."), ephemeral=True)
        await ctx.send(embed=helpers.ok(f"Unbanned **{user}**."))
        await self._log(ctx, "Unban", user, reason)

    # ------------------------------------------------------------------ timeout
    @commands.hybrid_command(name="timeout", description="Mute a member for a while (e.g. 10m, 2h, 1d)")
    @commands.guild_only()
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def timeout_cmd(self, ctx, member: discord.Member, duration: str, *, reason: Optional[str] = None):
        problem = helpers.can_moderate(ctx, member)
        if problem:
            return await ctx.send(embed=helpers.err(problem), ephemeral=True)
        seconds = helpers.parse_duration(duration)
        if not seconds:
            return await ctx.send(embed=helpers.err("Use a duration like `10m`, `2h` or `1d`."), ephemeral=True)
        if seconds > 28 * 86400:
            return await ctx.send(embed=helpers.err("Maximum timeout is 28 days."), ephemeral=True)
        await member.timeout(timedelta(seconds=seconds), reason=f"{ctx.author}: {reason or 'No reason'}")
        await ctx.send(embed=helpers.ok(f"Timed out **{member}** for `{duration}`. Reason: {reason or 'none'}"))
        await self._log(ctx, f"Timeout ({duration})", member, reason)

    @commands.hybrid_command(name="untimeout", description="Remove a member's timeout")
    @commands.guild_only()
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def untimeout(self, ctx, member: discord.Member):
        await member.timeout(None, reason=f"{ctx.author}: untimeout")
        await ctx.send(embed=helpers.ok(f"Removed the timeout from **{member}**."))
        await self._log(ctx, "Untimeout", member, None)

    # ----------------------------------------------------------------- warnings
    @commands.hybrid_command(name="warn", description="Warn a member")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member: discord.Member, *, reason: str):
        problem = helpers.can_moderate(ctx, member)
        if problem:
            return await ctx.send(embed=helpers.err(problem), ephemeral=True)
        warns = self.bot.store.get(ctx.guild.id)["warnings"].setdefault(str(member.id), [])
        warns.append({"reason": reason, "mod": ctx.author.id, "time": int(time.time())})
        self.bot.store.save()
        await self._dm(member, f"You were warned in **{ctx.guild.name}**: {reason}")
        await ctx.send(embed=helpers.ok(f"Warned **{member}** (warning #{len(warns)}). Reason: {reason}"))
        await self._log(ctx, f"Warn #{len(warns)}", member, reason)

    @commands.hybrid_command(name="warnings", description="Show a member's warnings")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def warnings(self, ctx, member: discord.Member):
        warns = self.bot.store.get(ctx.guild.id)["warnings"].get(str(member.id), [])
        if not warns:
            return await ctx.send(embed=helpers.ok(f"**{member}** has no warnings."))
        lines = [
            f"`{i}.` {w['reason']} - <@{w['mod']}> <t:{w['time']}:R>"
            for i, w in enumerate(warns[-15:], start=max(1, len(warns) - 14))
        ]
        await ctx.send(embed=helpers.embed(f"Warnings for {member}", "\n".join(lines)))

    @commands.hybrid_command(name="clearwarnings", description="Delete all warnings of a member")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def clearwarnings(self, ctx, member: discord.Member):
        self.bot.store.get(ctx.guild.id)["warnings"].pop(str(member.id), None)
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"Cleared warnings for **{member}**."))

    # -------------------------------------------------------------- channel tools
    @commands.hybrid_command(name="purge", description="Delete recent messages (optionally only from one member)")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True, read_message_history=True)
    async def purge(self, ctx, amount: commands.Range[int, 1, 500], member: Optional[discord.Member] = None):
        await ctx.defer(ephemeral=True)
        check = (lambda m: m.author.id == member.id) if member else None
        limit = amount + (1 if ctx.interaction is None and member is None else 0)
        deleted = await ctx.channel.purge(limit=limit, check=check)
        count = len(deleted) - (1 if ctx.interaction is None and member is None else 0)
        embed = helpers.ok(f"Deleted **{max(count, 0)}** messages.")
        if ctx.interaction:
            await ctx.send(embed=embed, ephemeral=True)
        else:
            await ctx.send(embed=embed, delete_after=5)

    @commands.hybrid_command(name="slowmode", description="Set slowmode in this channel (0 turns it off)")
    @commands.guild_only()
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: commands.Range[int, 0, 21600]):
        await ctx.channel.edit(slowmode_delay=seconds, reason=f"{ctx.author}: slowmode")
        text = f"Slowmode set to **{seconds}s**." if seconds else "Slowmode turned off."
        await ctx.send(embed=helpers.ok(text))

    @commands.hybrid_command(name="lock", description="Stop everyone from chatting in a channel")
    @commands.guild_only()
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        if not isinstance(channel, discord.TextChannel):
            return await ctx.send(embed=helpers.err("Use this in a text channel."), ephemeral=True)
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"{ctx.author}: lock")
        await ctx.send(embed=helpers.ok(f"🔒 Locked {channel.mention}."))

    @commands.hybrid_command(name="unlock", description="Let everyone chat in a channel again")
    @commands.guild_only()
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        if not isinstance(channel, discord.TextChannel):
            return await ctx.send(embed=helpers.err("Use this in a text channel."), ephemeral=True)
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"{ctx.author}: unlock")
        await ctx.send(embed=helpers.ok(f"🔓 Unlocked {channel.mention}."))

    # ------------------------------------------------------------------- roles
    def _role_problem(self, ctx, role):
        if role.managed or role.is_default():
            return "That role can't be given or removed manually."
        if role >= ctx.guild.me.top_role:
            return "That role is above my highest role."
        if ctx.author.id != ctx.guild.owner_id and role >= ctx.author.top_role:
            return "That role is above your highest role."
        return None

    @commands.hybrid_command(name="addrole", description="Give a role to a member")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def addrole(self, ctx, member: discord.Member, role: discord.Role):
        problem = self._role_problem(ctx, role)
        if problem:
            return await ctx.send(embed=helpers.err(problem), ephemeral=True)
        await member.add_roles(role, reason=f"{ctx.author}: addrole")
        await ctx.send(embed=helpers.ok(f"Gave **{role.name}** to **{member}**."))

    @commands.hybrid_command(name="removerole", description="Take a role from a member")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def removerole(self, ctx, member: discord.Member, role: discord.Role):
        problem = self._role_problem(ctx, role)
        if problem:
            return await ctx.send(embed=helpers.err(problem), ephemeral=True)
        await member.remove_roles(role, reason=f"{ctx.author}: removerole")
        await ctx.send(embed=helpers.ok(f"Removed **{role.name}** from **{member}**."))


async def setup(bot):
    await bot.add_cog(Moderation(bot))
