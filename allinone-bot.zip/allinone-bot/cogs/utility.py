import platform
import time
from typing import Optional

import discord
from discord.ext import commands

import config
from utils import helpers


class Utility(commands.Cog, name="Utility"):
    """Help, info and small tools."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Show all commands")
    async def help_cmd(self, ctx):
        e = helpers.embed(
            "📖 Help",
            f"Use `/` slash commands or the prefix `{config.PREFIX}`.\n"
            "Quick start: `/antinuke setup`, `/vc setup`, `/welcome channel`, `/play`.",
        )
        for name, cog in sorted(self.bot.cogs.items()):
            names = []
            for cmd in cog.get_commands():
                if cmd.hidden:
                    continue
                if isinstance(cmd, commands.Group):
                    names.extend(f"{cmd.name} {sub.name}" for sub in sorted(cmd.commands, key=lambda c: c.name))
                else:
                    names.append(cmd.name)
            if names:
                e.add_field(name=name, value=" ".join(f"`{n}`" for n in names)[:1024], inline=False)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="ping", description="Check the bot's latency")
    async def ping(self, ctx):
        await ctx.send(embed=helpers.ok(f"Pong! `{round(self.bot.latency * 1000)}ms`"))

    @commands.hybrid_command(name="botinfo", description="Bot statistics")
    async def botinfo(self, ctx):
        uptime = int(time.time() - self.bot.started_at)
        days, rest = divmod(uptime, 86400)
        hours, rest = divmod(rest, 3600)
        minutes = rest // 60
        e = helpers.embed("🤖 Bot info")
        e.add_field(name="Servers", value=str(len(self.bot.guilds)))
        e.add_field(name="Users", value=str(sum(g.member_count or 0 for g in self.bot.guilds)))
        e.add_field(name="Uptime", value=f"{days}d {hours}h {minutes}m")
        e.add_field(name="Python", value=platform.python_version())
        e.add_field(name="discord.py", value=discord.__version__)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="invite", description="Get the link to add this bot to a server")
    async def invite(self, ctx):
        url = discord.utils.oauth_url(
            self.bot.user.id,
            permissions=discord.Permissions(administrator=True),
            scopes=("bot", "applications.commands"),
        )
        await ctx.send(embed=helpers.embed("Invite me", f"[Click here to add the bot]({url})"))

    @commands.hybrid_command(name="serverinfo", description="Information about this server")
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        e = helpers.embed(g.name)
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>")
        e.add_field(name="Members", value=str(g.member_count))
        e.add_field(name="Channels", value=str(len(g.channels)))
        e.add_field(name="Roles", value=str(len(g.roles)))
        e.add_field(name="Boosts", value=f"{g.premium_subscription_count} (level {g.premium_tier})")
        e.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:D>")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="userinfo", description="Information about a member")
    @commands.guild_only()
    async def userinfo(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        e = helpers.embed(str(member), color=member.color.value or config.EMBED_COLOR)
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="ID", value=str(member.id))
        e.add_field(name="Created", value=f"<t:{int(member.created_at.timestamp())}:R>")
        if member.joined_at:
            e.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>")
        roles = [r.mention for r in reversed(member.roles) if not r.is_default()]
        e.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:15]) or "None", inline=False)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="avatar", description="Show someone's avatar")
    async def avatar(self, ctx, user: Optional[discord.User] = None):
        user = user or ctx.author
        e = helpers.embed(f"{user.display_name}'s avatar")
        e.set_image(url=user.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="sync", hidden=True)
    @commands.is_owner()
    async def sync(self, ctx):
        """Owner only: re-sync slash commands."""
        synced = await self.bot.tree.sync()
        await ctx.send(embed=helpers.ok(f"Synced {len(synced)} slash commands."))


async def setup(bot):
    await bot.add_cog(Utility(bot))
