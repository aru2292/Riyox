import time
from typing import Optional

import discord
from discord.ext import commands

from utils import helpers

OWNER_PERMS = dict(view_channel=True, connect=True, manage_channels=True, move_members=True)


class TempVC(commands.Cog, name="TempVC"):
    """Join-to-create voice channels. Join the hub, get your own room."""

    def __init__(self, bot):
        self.bot = bot
        self.cooldowns = {}

    def cfg(self, guild):
        return self.bot.store.get(guild.id)["tempvc"]

    # ------------------------------------------------------------------ events
    @commands.Cog.listener()
    async def on_ready(self):
        """Clean up rooms that were deleted or emptied while the bot was offline."""
        for guild in self.bot.guilds:
            cfg = self.cfg(guild)
            for cid in list(cfg["channels"]):
                channel = guild.get_channel(int(cid))
                if channel is None:
                    cfg["channels"].pop(cid, None)
                elif not [m for m in channel.members if not m.bot]:
                    cfg["channels"].pop(cid, None)
                    try:
                        await channel.delete(reason="Temp VC was empty")
                    except discord.HTTPException:
                        pass
        self.bot.store.save()

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return
        cfg = self.cfg(member.guild)
        if (
            after.channel is not None
            and cfg["hub"]
            and after.channel.id == cfg["hub"]
            and after.channel != before.channel
        ):
            await self.create_room(member, after.channel)
        if (
            before.channel is not None
            and before.channel != after.channel
            and str(before.channel.id) in cfg["channels"]
        ):
            await self.handle_leave(member, before.channel)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        cfg = self.cfg(channel.guild)
        if cfg["channels"].pop(str(channel.id), None) is not None:
            self.bot.store.save()

    async def create_room(self, member, hub):
        now = time.monotonic()
        if now - self.cooldowns.get(member.id, 0) < 5:
            return
        self.cooldowns[member.id] = now

        guild = member.guild
        overwrites = dict(hub.overwrites)
        overwrites[member] = discord.PermissionOverwrite(**OWNER_PERMS)
        try:
            room = await guild.create_voice_channel(
                f"{member.display_name}'s room"[:100],
                category=hub.category,
                overwrites=overwrites,
                reason="Join to Create",
            )
        except discord.HTTPException:
            return
        try:
            await member.move_to(room)
        except discord.HTTPException:
            try:
                await room.delete(reason="User left before being moved")
            except discord.HTTPException:
                pass
            return
        self.cfg(guild)["channels"][str(room.id)] = member.id
        self.bot.store.save()

    async def handle_leave(self, member, channel):
        cfg = self.cfg(channel.guild)
        humans = [m for m in channel.members if not m.bot]
        if not humans:
            cfg["channels"].pop(str(channel.id), None)
            self.bot.store.save()
            try:
                await channel.delete(reason="Temp VC is empty")
            except discord.HTTPException:
                pass
            return
        if cfg["channels"].get(str(channel.id)) == member.id:
            await self.give_ownership(channel, member, humans[0])

    async def give_ownership(self, channel, old, new):
        self.cfg(channel.guild)["channels"][str(channel.id)] = new.id
        self.bot.store.save()
        try:
            await channel.set_permissions(new, **OWNER_PERMS)
            if old is not None:
                await channel.set_permissions(old, overwrite=None)
        except discord.HTTPException:
            pass

    def room_of(self, ctx):
        """Return (channel, error). Checks the author is in a temp room they may control."""
        voice = ctx.author.voice
        if voice is None or voice.channel is None:
            return None, "Join your temporary voice channel first."
        owner = self.cfg(ctx.guild)["channels"].get(str(voice.channel.id))
        if owner is None:
            return None, "This isn't a temporary voice channel."
        if owner != ctx.author.id and not ctx.author.guild_permissions.manage_channels:
            return None, "Only the owner of this room can do that."
        return voice.channel, None

    # ---------------------------------------------------------------- commands
    @commands.hybrid_group(
        name="vc",
        description="Join-to-create voice channels",
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def vc_group(self, ctx):
        await helpers.group_help(ctx)

    @vc_group.command(name="setup", description="Create the Join-to-Create hub channel")
    @commands.has_permissions(manage_guild=True)
    @commands.bot_has_guild_permissions(manage_channels=True, move_members=True)
    async def vc_setup(self, ctx):
        guild = ctx.guild
        cfg = self.cfg(guild)
        if cfg["hub"] and guild.get_channel(cfg["hub"]):
            return await ctx.send(
                embed=helpers.err(f"Already set up: {guild.get_channel(cfg['hub']).mention}"), ephemeral=True
            )
        category = await guild.create_category("Temporary Voice", reason="Join to Create setup")
        hub = await guild.create_voice_channel("➕ Join to Create", category=category, reason="Join to Create setup")
        cfg["hub"] = hub.id
        cfg["category"] = category.id
        self.bot.store.save()
        await ctx.send(
            embed=helpers.ok(
                f"Done! Join {hub.mention} and I'll create your own room.\n"
                "Owners can use `/vc name`, `/vc limit`, `/vc lock`, `/vc unlock`, `/vc permit`, `/vc kick`, `/vc transfer`."
            )
        )

    @vc_group.command(name="disable", description="Turn off Join-to-Create (channels stay)")
    @commands.has_permissions(manage_guild=True)
    async def vc_disable(self, ctx):
        cfg = self.cfg(ctx.guild)
        cfg["hub"] = None
        self.bot.store.save()
        await ctx.send(embed=helpers.ok("Join-to-Create is off. You can delete the hub channel."))

    @vc_group.command(name="name", description="Rename your temporary room")
    async def vc_name(self, ctx, *, new_name: str):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        await ctx.defer()
        await channel.edit(name=new_name[:100], reason=f"{ctx.author} renamed temp VC")
        await ctx.send(embed=helpers.ok(f"Room renamed to **{new_name[:100]}**."))

    @vc_group.command(name="limit", description="Set the user limit of your room (0 = unlimited)")
    async def vc_limit(self, ctx, limit: commands.Range[int, 0, 99]):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        await channel.edit(user_limit=limit)
        await ctx.send(embed=helpers.ok(f"User limit set to **{limit or 'unlimited'}**."))

    @vc_group.command(name="lock", description="Nobody new can join your room")
    async def vc_lock(self, ctx):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        await channel.set_permissions(ctx.guild.default_role, connect=False)
        await ctx.send(embed=helpers.ok("🔒 Room locked. Use `/vc permit` to let someone in."))

    @vc_group.command(name="unlock", description="Let everyone join your room again")
    async def vc_unlock(self, ctx):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        await channel.set_permissions(ctx.guild.default_role, connect=None)
        await ctx.send(embed=helpers.ok("🔓 Room unlocked."))

    @vc_group.command(name="permit", description="Allow one member to join your locked room")
    async def vc_permit(self, ctx, member: discord.Member):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        await channel.set_permissions(member, connect=True, view_channel=True)
        await ctx.send(embed=helpers.ok(f"{member.mention} can join your room."))

    @vc_group.command(name="kick", description="Remove a member from your room")
    async def vc_kick(self, ctx, member: discord.Member):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        if member.voice is None or member.voice.channel != channel:
            return await ctx.send(embed=helpers.err("That member isn't in your room."), ephemeral=True)
        if member.id == ctx.author.id:
            return await ctx.send(embed=helpers.err("You can't kick yourself."), ephemeral=True)
        await member.move_to(None)
        await channel.set_permissions(member, connect=False)
        await ctx.send(embed=helpers.ok(f"Removed {member.mention} from your room."))

    @vc_group.command(name="transfer", description="Give your room to another member")
    async def vc_transfer(self, ctx, member: discord.Member):
        channel, error = self.room_of(ctx)
        if error:
            return await ctx.send(embed=helpers.err(error), ephemeral=True)
        if member.bot or member.voice is None or member.voice.channel != channel:
            return await ctx.send(embed=helpers.err("Pick a person who is in your room."), ephemeral=True)
        await self.give_ownership(channel, ctx.author, member)
        await ctx.send(embed=helpers.ok(f"{member.mention} is now the owner of this room."))

    @vc_group.command(name="claim", description="Take over a room whose owner left")
    async def vc_claim(self, ctx):
        voice = ctx.author.voice
        if voice is None or voice.channel is None:
            return await ctx.send(embed=helpers.err("Join the room first."), ephemeral=True)
        channel = voice.channel
        owner_id: Optional[int] = self.cfg(ctx.guild)["channels"].get(str(channel.id))
        if owner_id is None:
            return await ctx.send(embed=helpers.err("This isn't a temporary voice channel."), ephemeral=True)
        if any(m.id == owner_id for m in channel.members):
            return await ctx.send(embed=helpers.err("The owner is still in the room."), ephemeral=True)
        await self.give_ownership(channel, ctx.guild.get_member(owner_id), ctx.author)
        await ctx.send(embed=helpers.ok("You are now the owner of this room."))


async def setup(bot):
    await bot.add_cog(TempVC(bot))
