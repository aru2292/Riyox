from typing import Optional

import discord
from discord.ext import commands

from utils import helpers


def render(template, member):
    return (
        template.replace("{user}", member.mention)
        .replace("{username}", member.display_name)
        .replace("{server}", member.guild.name)
        .replace("{count}", str(member.guild.member_count))
    )


class Welcome(commands.Cog, name="Welcome"):
    """Welcome messages and an automatic role for new members."""

    def __init__(self, bot):
        self.bot = bot

    def cfg(self, guild):
        return self.bot.store.get(guild.id)["welcome"]

    @commands.Cog.listener()
    async def on_member_join(self, member):
        cfg = self.cfg(member.guild)

        if cfg["autorole"]:
            role = member.guild.get_role(cfg["autorole"])
            if role is not None and role < member.guild.me.top_role and not role.managed:
                try:
                    await member.add_roles(role, reason="Welcome auto-role")
                except discord.HTTPException:
                    pass

        if cfg["channel"]:
            channel = member.guild.get_channel(cfg["channel"])
            if channel is not None:
                try:
                    await channel.send(render(cfg["message"], member))
                except discord.HTTPException:
                    pass

    @commands.hybrid_group(
        name="welcome",
        description="Welcome messages and auto-role",
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def welcome(self, ctx):
        await helpers.group_help(ctx)

    @welcome.command(name="channel", description="Set (or clear) the welcome channel")
    @commands.has_permissions(manage_guild=True)
    async def w_channel(self, ctx, channel: Optional[discord.TextChannel] = None):
        self.cfg(ctx.guild)["channel"] = channel.id if channel else None
        self.bot.store.save()
        text = f"Welcome messages will go to {channel.mention}." if channel else "Welcome messages turned off."
        await ctx.send(embed=helpers.ok(text))

    @welcome.command(name="message", description="Set the text. Use {user} {username} {server} {count}")
    @commands.has_permissions(manage_guild=True)
    async def w_message(self, ctx, *, text: str):
        self.cfg(ctx.guild)["message"] = text[:1500]
        self.bot.store.save()
        await ctx.send(embed=helpers.ok("Welcome message updated. Use `/welcome test` to preview it."))

    @welcome.command(name="autorole", description="Give this role to every new member (leave empty to turn off)")
    @commands.has_permissions(manage_guild=True)
    async def w_autorole(self, ctx, role: Optional[discord.Role] = None):
        if role is not None and (role.managed or role >= ctx.guild.me.top_role):
            return await ctx.send(
                embed=helpers.err("I can't give that role. Put my role above it first."), ephemeral=True
            )
        self.cfg(ctx.guild)["autorole"] = role.id if role else None
        self.bot.store.save()
        text = f"New members will get **{role.name}**." if role else "Auto-role turned off."
        await ctx.send(embed=helpers.ok(text))

    @welcome.command(name="test", description="Preview the welcome message")
    @commands.has_permissions(manage_guild=True)
    async def w_test(self, ctx):
        await ctx.send(render(self.cfg(ctx.guild)["message"], ctx.author))


async def setup(bot):
    await bot.add_cog(Welcome(bot))
