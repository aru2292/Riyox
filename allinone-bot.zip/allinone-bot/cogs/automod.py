import re
import time
from collections import defaultdict, deque
from datetime import timedelta
from typing import Literal

import discord
from discord.ext import commands

from utils import helpers

INVITE_RE = re.compile(r"(?:discord(?:app)?\.com/invite|discord\.gg)/[A-Za-z0-9-]+", re.I)
LINK_RE = re.compile(r"https?://\S+", re.I)


class AutoMod(commands.Cog, name="AutoMod"):
    """Deletes invites, links, spam, mass mentions and bad words."""

    def __init__(self, bot):
        self.bot = bot
        self.spam = defaultdict(deque)

    def cfg(self, guild):
        return self.bot.store.get(guild.id)["automod"]

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.guild is None:
            return
        member = message.author
        if not isinstance(member, discord.Member):
            return
        perms = member.guild_permissions
        if perms.administrator or perms.manage_messages:
            return
        cfg = self.cfg(message.guild)
        if not (cfg["antiinvite"] or cfg["antilink"] or cfg["antispam"] or cfg["massmention"] or cfg["badwords"]):
            return
        if not message.channel.permissions_for(message.guild.me).manage_messages:
            return

        content = message.content
        reason = None
        punish = False
        if cfg["antiinvite"] and INVITE_RE.search(content):
            reason = "Invite links are not allowed here."
        elif cfg["antilink"] and LINK_RE.search(content):
            reason = "Links are not allowed here."
        elif cfg["badwords"] and any(w in content.lower() for w in cfg["badwords"]):
            reason = "Please watch your language."
        elif cfg["massmention"]:
            mentioned = {u.id for u in message.mentions if u.id != member.id}
            if len(mentioned) + len(message.role_mentions) > cfg["massmention"]:
                reason = "Too many mentions in one message."
                punish = True

        if reason:
            try:
                await message.delete()
            except discord.HTTPException:
                return
            await message.channel.send(f"{member.mention} {reason}", delete_after=5)
            if punish:
                try:
                    await member.timeout(timedelta(minutes=10), reason="AutoMod: mass mention")
                except discord.HTTPException:
                    pass
            return

        if cfg["antispam"]:
            key = (message.guild.id, member.id)
            now = time.monotonic()
            dq = self.spam[key]
            dq.append(now)
            while dq and now - dq[0] > 5:
                dq.popleft()
            if len(dq) >= 6:
                dq.clear()
                try:
                    await member.timeout(timedelta(minutes=5), reason="AutoMod: spam")
                except discord.HTTPException:
                    pass
                try:
                    await message.channel.purge(limit=15, check=lambda m: m.author.id == member.id)
                except discord.HTTPException:
                    pass
                await message.channel.send(
                    f"{member.mention} was timed out for 5 minutes (spam).", delete_after=8
                )

    # ----------------------------------------------------------------- commands
    @commands.hybrid_group(
        name="automod",
        description="Automatic message moderation",
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def automod(self, ctx):
        await helpers.group_help(ctx)

    @automod.command(name="status", description="Show AutoMod settings")
    @commands.has_permissions(manage_guild=True)
    async def am_status(self, ctx):
        cfg = self.cfg(ctx.guild)

        def mark(flag):
            return "🟢 on" if flag else "🔴 off"

        e = helpers.embed("🤖 AutoMod")
        e.add_field(name="Block invites", value=mark(cfg["antiinvite"]))
        e.add_field(name="Block links", value=mark(cfg["antilink"]))
        e.add_field(name="Anti-spam", value=mark(cfg["antispam"]))
        e.add_field(
            name="Mass mention limit",
            value=str(cfg["massmention"]) if cfg["massmention"] else "🔴 off",
        )
        e.add_field(name="Bad words", value=f"{len(cfg['badwords'])} saved")
        e.set_footer(text="Members with Manage Messages are never touched.")
        await ctx.send(embed=e, ephemeral=True)

    @automod.command(name="toggle", description="Turn a feature on or off")
    @commands.has_permissions(manage_guild=True)
    async def am_toggle(self, ctx, feature: Literal["antiinvite", "antilink", "antispam"]):
        cfg = self.cfg(ctx.guild)
        cfg[feature] = not cfg[feature]
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"`{feature}` is now **{'on' if cfg[feature] else 'off'}**."))

    @automod.command(name="massmention", description="Max mentions per message (0 = off)")
    @commands.has_permissions(manage_guild=True)
    async def am_massmention(self, ctx, limit: commands.Range[int, 0, 50]):
        self.cfg(ctx.guild)["massmention"] = limit
        self.bot.store.save()
        text = f"Mass-mention limit set to **{limit}**." if limit else "Mass-mention protection turned off."
        await ctx.send(embed=helpers.ok(text))

    @automod.command(name="badword_add", description="Add a word to the blocked list")
    @commands.has_permissions(manage_guild=True)
    async def am_bw_add(self, ctx, *, word: str):
        word = word.lower().strip()
        words = self.cfg(ctx.guild)["badwords"]
        if word and word not in words:
            words.append(word)
            self.bot.store.save()
        if ctx.interaction is None:
            try:
                await ctx.message.delete()
            except discord.HTTPException:
                pass
        await ctx.send(embed=helpers.ok("Word added."), ephemeral=True)

    @automod.command(name="badword_remove", description="Remove a word from the blocked list")
    @commands.has_permissions(manage_guild=True)
    async def am_bw_remove(self, ctx, *, word: str):
        word = word.lower().strip()
        words = self.cfg(ctx.guild)["badwords"]
        if word in words:
            words.remove(word)
            self.bot.store.save()
        await ctx.send(embed=helpers.ok("Word removed."), ephemeral=True)

    @automod.command(name="badword_list", description="Show blocked words (only you can see it)")
    @commands.has_permissions(manage_guild=True)
    async def am_bw_list(self, ctx):
        words = self.cfg(ctx.guild)["badwords"]
        await ctx.send(embed=helpers.embed("Blocked words", ", ".join(words) or "None"), ephemeral=True)


async def setup(bot):
    await bot.add_cog(AutoMod(bot))
