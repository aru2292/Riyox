from typing import Optional

import discord
from discord.ext import commands

import config
from utils import helpers


def short(text, limit=1000):
    text = text or "*(no text)*"
    return text if len(text) <= limit else text[: limit - 3] + "..."


class Logs(commands.Cog, name="Logs"):
    """Logs deleted/edited messages, joins, leaves and voice activity."""

    def __init__(self, bot):
        self.bot = bot

    async def send(self, guild, title, description, color=helpers.ORANGE):
        e = discord.Embed(
            title=title,
            description=description,
            color=color,
            timestamp=discord.utils.utcnow(),
        )
        await helpers.send_log(self.bot, guild, e)

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.guild is None or message.author.bot:
            return
        await self.send(
            message.guild,
            "🗑️ Message deleted",
            f"**Author:** {message.author.mention}\n**Channel:** {message.channel.mention}\n"
            f"**Content:** {short(message.content)}",
            helpers.RED,
        )

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.guild is None or before.author.bot or before.content == after.content:
            return
        await self.send(
            before.guild,
            "✏️ Message edited",
            f"**Author:** {before.author.mention}\n**Channel:** {before.channel.mention} "
            f"[Jump]({after.jump_url})\n**Before:** {short(before.content, 500)}\n"
            f"**After:** {short(after.content, 500)}",
        )

    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.send(
            member.guild,
            "📥 Member joined",
            f"{member.mention} (`{member.id}`)\nAccount created <t:{int(member.created_at.timestamp())}:R>",
            helpers.GREEN,
        )

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await self.send(member.guild, "📤 Member left", f"{member} (`{member.id}`)", helpers.RED)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel or member.bot:
            return
        if before.channel is None:
            text = f"{member.mention} joined {after.channel.mention}"
        elif after.channel is None:
            text = f"{member.mention} left {before.channel.mention}"
        else:
            text = f"{member.mention} moved {before.channel.mention} -> {after.channel.mention}"
        await self.send(member.guild, "🔊 Voice", text, config.EMBED_COLOR)

    @commands.hybrid_group(
        name="logs",
        description="Server activity logs",
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def logs(self, ctx):
        await helpers.group_help(ctx)

    @logs.command(name="channel", description="Set (or clear) the log channel")
    @commands.has_permissions(manage_guild=True)
    async def logs_channel(self, ctx, channel: Optional[discord.TextChannel] = None):
        self.bot.store.get(ctx.guild.id)["logs"]["channel"] = channel.id if channel else None
        self.bot.store.save()
        text = f"Logs will be sent to {channel.mention}." if channel else "Logging turned off."
        await ctx.send(embed=helpers.ok(text))


async def setup(bot):
    await bot.add_cog(Logs(bot))
