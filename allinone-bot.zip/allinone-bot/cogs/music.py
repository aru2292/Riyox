import asyncio
import os
import random
import re
import time
from dataclasses import dataclass, field
from typing import Literal, Optional

import discord
import yt_dlp
from discord.ext import commands

import config
from utils import helpers

URL_RE = re.compile(r"^https?://", re.I)

YTDL_OPTS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "no_warnings": True,
    "source_address": "0.0.0.0",  # force IPv4, avoids many connection problems
    "socket_timeout": 15,
    # yt-dlp needs a JavaScript runtime for YouTube. Deno or Node both work.
    "js_runtimes": {"deno": {}, "node": {}},
}
if config.YT_COOKIES and os.path.exists(config.YT_COOKIES):
    YTDL_OPTS["cookiefile"] = config.YT_COOKIES

FFMPEG_OPTS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}


def _extract(query):
    """Blocking: look up a single track. Run in a thread."""
    with yt_dlp.YoutubeDL(YTDL_OPTS) as ydl:
        info = ydl.extract_info(query, download=False)
    if info is None:
        raise RuntimeError("Nothing found.")
    if "entries" in info:
        entries = [e for e in info["entries"] if e]
        if not entries:
            raise RuntimeError("No results found.")
        info = entries[0]
    return info


def _extract_playlist(url):
    """Blocking: list the entries of a playlist (fast, no stream URLs yet)."""
    opts = {**YTDL_OPTS, "noplaylist": False, "extract_flat": "in_playlist", "playlistend": 50}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    return [e for e in ((info or {}).get("entries") or []) if e]


@dataclass
class Track:
    title: str
    webpage_url: str
    duration: Optional[int]
    thumbnail: Optional[str]
    requester: discord.abc.User
    stream_url: Optional[str] = None
    resolved_at: float = 0.0

    @classmethod
    def from_info(cls, info, requester):
        return cls(
            title=info.get("title") or "Unknown title",
            webpage_url=info.get("webpage_url") or info.get("original_url") or info.get("url"),
            duration=info.get("duration"),
            thumbnail=info.get("thumbnail"),
            requester=requester,
            stream_url=info.get("url"),
            resolved_at=time.monotonic(),
        )

    @classmethod
    def from_flat(cls, entry, requester):
        url = entry.get("url") or entry.get("webpage_url")
        if url and not URL_RE.match(url):
            url = None
        if not url and entry.get("id"):
            url = f"https://www.youtube.com/watch?v={entry['id']}"
        if not url:
            return None
        thumbs = entry.get("thumbnails") or []
        return cls(
            title=entry.get("title") or "Unknown title",
            webpage_url=url,
            duration=entry.get("duration"),
            thumbnail=thumbs[-1].get("url") if thumbs else None,
            requester=requester,
        )

    async def ensure_stream(self):
        """Stream URLs expire, so refresh them if they are old or missing."""
        if self.stream_url and time.monotonic() - self.resolved_at < 900:
            return
        info = await asyncio.to_thread(_extract, self.webpage_url)
        self.stream_url = info.get("url")
        self.resolved_at = time.monotonic()
        if not self.stream_url:
            raise RuntimeError("No playable stream found.")


@dataclass
class GuildPlayer:
    queue: list = field(default_factory=list)
    current: Optional[Track] = None
    loop: str = "off"  # off | one | all
    volume: float = 0.5
    text_channel: Optional[discord.abc.Messageable] = None
    skip_requested: bool = False
    idle_task: Optional[asyncio.Task] = None


class Controls(discord.ui.View):
    """Buttons under the Now Playing message."""

    def __init__(self, cog):
        super().__init__(timeout=1800)
        self.cog = cog

    async def interaction_check(self, interaction):
        vc = interaction.guild.voice_client if interaction.guild else None
        voice = getattr(interaction.user, "voice", None)
        if vc is None or voice is None or voice.channel != vc.channel:
            await interaction.response.send_message(
                "Join my voice channel to use these buttons.", ephemeral=True
            )
            return False
        return True

    @discord.ui.button(emoji="⏯️", style=discord.ButtonStyle.secondary)
    async def pause_resume(self, interaction, button):
        vc = interaction.guild.voice_client
        if vc.is_paused():
            vc.resume()
            text = "▶️ Resumed."
        elif vc.is_playing():
            vc.pause()
            text = "⏸️ Paused."
        else:
            text = "Nothing is playing."
        await interaction.response.send_message(text, ephemeral=True)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.primary)
    async def skip(self, interaction, button):
        text = "⏭️ Skipped." if self.cog.do_skip(interaction.guild) else "Nothing is playing."
        await interaction.response.send_message(text, ephemeral=True)

    @discord.ui.button(emoji="⏹️", style=discord.ButtonStyle.danger)
    async def stop_btn(self, interaction, button):
        text = "⏹️ Stopped and cleared the queue." if self.cog.do_stop(interaction.guild) else "Nothing is playing."
        await interaction.response.send_message(text, ephemeral=True)

    @discord.ui.button(emoji="🔁", style=discord.ButtonStyle.secondary)
    async def loop_btn(self, interaction, button):
        player = self.cog.player(interaction.guild.id)
        player.loop = {"off": "one", "one": "all", "all": "off"}[player.loop]
        await interaction.response.send_message(f"🔁 Loop: **{player.loop}**", ephemeral=True)


class Music(commands.Cog, name="Music"):
    """YouTube music with a queue, loop, volume and buttons. Free, no API key."""

    def __init__(self, bot):
        self.bot = bot
        self.players = {}

    def player(self, guild_id):
        if guild_id not in self.players:
            self.players[guild_id] = GuildPlayer()
        return self.players[guild_id]

    async def cog_unload(self):
        for vc in list(self.bot.voice_clients):
            await vc.disconnect(force=True)

    # --------------------------------------------------------------- core logic
    def np_embed(self, track, title="🎶 Now Playing"):
        e = helpers.embed(title, f"[{track.title}]({track.webpage_url})")
        e.add_field(name="Duration", value=helpers.fmt_duration(track.duration))
        e.add_field(name="Requested by", value=track.requester.mention)
        if track.thumbnail:
            e.set_thumbnail(url=track.thumbnail)
        return e

    def do_skip(self, guild):
        vc = guild.voice_client
        if vc is None or not (vc.is_playing() or vc.is_paused()):
            return False
        self.player(guild.id).skip_requested = True
        vc.stop()
        return True

    def do_stop(self, guild):
        vc = guild.voice_client
        p = self.player(guild.id)
        p.queue.clear()
        p.loop = "off"
        if vc is not None and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            return True
        return False

    def cancel_idle(self, p):
        if p.idle_task is not None:
            p.idle_task.cancel()
            p.idle_task = None

    def schedule_idle(self, guild):
        p = self.player(guild.id)
        self.cancel_idle(p)
        p.idle_task = asyncio.create_task(self._idle_leave(guild))

    async def _idle_leave(self, guild):
        try:
            await asyncio.sleep(180)
        except asyncio.CancelledError:
            return
        vc = guild.voice_client
        p = self.player(guild.id)
        if vc is not None and not vc.is_playing() and not vc.is_paused() and not p.queue:
            await vc.disconnect()

    async def play_next(self, guild, announce=True):
        p = self.player(guild.id)
        vc = guild.voice_client
        if vc is None or not vc.is_connected():
            p.current = None
            p.queue.clear()
            return
        self.cancel_idle(p)

        skipped, p.skip_requested = p.skip_requested, False
        if p.loop == "one" and p.current is not None and not skipped:
            track = p.current
        else:
            if p.loop == "all" and p.current is not None:
                p.queue.append(p.current)
            if not p.queue:
                p.current = None
                self.schedule_idle(guild)
                return
            track = p.queue.pop(0)
        p.current = track

        try:
            await track.ensure_stream()
            source = discord.PCMVolumeTransformer(
                discord.FFmpegPCMAudio(track.stream_url, **FFMPEG_OPTS), volume=p.volume
            )
        except Exception as exc:
            if p.text_channel is not None:
                try:
                    await p.text_channel.send(
                        embed=helpers.err(f"Skipping **{track.title}**: `{str(exc)[:250]}`")
                    )
                except discord.HTTPException:
                    pass
            p.current = None
            return await self.play_next(guild)

        def after(error):
            if error:
                print(f"[music] player error: {error}")
            asyncio.run_coroutine_threadsafe(self.play_next(guild), self.bot.loop)

        try:
            vc.play(source, after=after)
        except discord.ClientException:
            p.queue.insert(0, track)
            p.current = None
            return

        if announce and p.text_channel is not None:
            try:
                await p.text_channel.send(embed=self.np_embed(track), view=Controls(self))
            except discord.HTTPException:
                pass

    async def ensure_voice(self, ctx):
        voice = ctx.author.voice
        if voice is None or voice.channel is None:
            await ctx.send(embed=helpers.err("Join a voice channel first."), ephemeral=True)
            return None
        channel = voice.channel
        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.view_channel and perms.connect and perms.speak):
            await ctx.send(
                embed=helpers.err(f"I need **Connect** and **Speak** permission in {channel.mention}."),
                ephemeral=True,
            )
            return None
        vc = ctx.guild.voice_client
        try:
            if vc is None:
                vc = await channel.connect(self_deaf=True)
            elif vc.channel != channel:
                if vc.is_playing() or vc.is_paused():
                    await ctx.send(
                        embed=helpers.err(f"I'm already playing in {vc.channel.mention}."), ephemeral=True
                    )
                    return None
                await vc.move_to(channel)
        except Exception as exc:
            await ctx.send(embed=helpers.err(f"Couldn't join the voice channel: `{exc}`"), ephemeral=True)
            return None
        return vc

    async def check_control(self, ctx):
        vc = ctx.guild.voice_client
        if vc is None:
            await ctx.send(embed=helpers.err("I'm not in a voice channel."), ephemeral=True)
            return None
        voice = ctx.author.voice
        if voice is None or voice.channel != vc.channel:
            await ctx.send(embed=helpers.err("You need to be in my voice channel."), ephemeral=True)
            return None
        return vc

    # ----------------------------------------------------------------- commands
    @commands.hybrid_command(name="play", description="Play a song from YouTube (name or link)")
    @commands.guild_only()
    async def play(self, ctx, *, query: str):
        await ctx.defer()
        vc = await self.ensure_voice(ctx)
        if vc is None:
            return
        p = self.player(ctx.guild.id)
        p.text_channel = ctx.channel

        query = query.strip()
        if not URL_RE.match(query):
            query = f"ytsearch1:{query}"
        try:
            info = await asyncio.to_thread(_extract, query)
        except Exception as exc:
            return await ctx.send(
                embed=helpers.err(f"Couldn't load that track.\n```{str(exc)[:400]}```"), ephemeral=True
            )

        track = Track.from_info(info, ctx.author)
        p.queue.append(track)
        idle = p.current is None and not vc.is_playing() and not vc.is_paused()
        if idle:
            await ctx.send(embed=self.np_embed(track), view=Controls(self))
            await self.play_next(ctx.guild, announce=False)
        else:
            await ctx.send(embed=self.np_embed(track, f"➕ Queued (#{len(p.queue)})"))

    @commands.hybrid_command(name="playlist", description="Queue a YouTube playlist (up to 50 songs)")
    @commands.guild_only()
    async def playlist(self, ctx, url: str):
        await ctx.defer()
        vc = await self.ensure_voice(ctx)
        if vc is None:
            return
        p = self.player(ctx.guild.id)
        p.text_channel = ctx.channel
        try:
            entries = await asyncio.to_thread(_extract_playlist, url.strip())
        except Exception as exc:
            return await ctx.send(
                embed=helpers.err(f"Couldn't load that playlist.\n```{str(exc)[:400]}```"), ephemeral=True
            )
        tracks = [t for t in (Track.from_flat(e, ctx.author) for e in entries) if t]
        if not tracks:
            return await ctx.send(embed=helpers.err("No playable songs found in that playlist."), ephemeral=True)
        idle = p.current is None and not vc.is_playing() and not vc.is_paused()
        p.queue.extend(tracks)
        await ctx.send(embed=helpers.ok(f"Added **{len(tracks)}** songs to the queue."))
        if idle:
            await self.play_next(ctx.guild)

    @commands.hybrid_command(name="skip", description="Skip the current song")
    @commands.guild_only()
    async def skip(self, ctx):
        if await self.check_control(ctx) is None:
            return
        if self.do_skip(ctx.guild):
            await ctx.send(embed=helpers.ok("⏭️ Skipped."))
        else:
            await ctx.send(embed=helpers.err("Nothing is playing."), ephemeral=True)

    @commands.hybrid_command(name="stop", description="Stop the music and clear the queue")
    @commands.guild_only()
    async def stop(self, ctx):
        if await self.check_control(ctx) is None:
            return
        self.do_stop(ctx.guild)
        await ctx.send(embed=helpers.ok("⏹️ Stopped and cleared the queue."))

    @commands.hybrid_command(name="pause", description="Pause the music")
    @commands.guild_only()
    async def pause(self, ctx):
        vc = await self.check_control(ctx)
        if vc is None:
            return
        if vc.is_playing():
            vc.pause()
            await ctx.send(embed=helpers.ok("⏸️ Paused."))
        else:
            await ctx.send(embed=helpers.err("Nothing is playing."), ephemeral=True)

    @commands.hybrid_command(name="resume", description="Resume the music")
    @commands.guild_only()
    async def resume(self, ctx):
        vc = await self.check_control(ctx)
        if vc is None:
            return
        if vc.is_paused():
            vc.resume()
            await ctx.send(embed=helpers.ok("▶️ Resumed."))
        else:
            await ctx.send(embed=helpers.err("Nothing is paused."), ephemeral=True)

    @commands.hybrid_command(name="queue", description="Show the song queue")
    @commands.guild_only()
    async def queue(self, ctx):
        p = self.player(ctx.guild.id)
        if p.current is None and not p.queue:
            return await ctx.send(embed=helpers.embed("Queue", "The queue is empty."))
        lines = []
        if p.current is not None:
            lines.append(f"**Now:** [{p.current.title}]({p.current.webpage_url})")
        for i, t in enumerate(p.queue[:10], start=1):
            lines.append(f"`{i}.` [{t.title}]({t.webpage_url}) `{helpers.fmt_duration(t.duration)}`")
        if len(p.queue) > 10:
            lines.append(f"...and **{len(p.queue) - 10}** more")
        e = helpers.embed("🎼 Queue", "\n".join(lines))
        e.set_footer(text=f"Loop: {p.loop} | Volume: {int(p.volume * 100)}%")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="nowplaying", description="Show the current song")
    @commands.guild_only()
    async def nowplaying(self, ctx):
        p = self.player(ctx.guild.id)
        if p.current is None:
            return await ctx.send(embed=helpers.err("Nothing is playing."), ephemeral=True)
        e = self.np_embed(p.current)
        e.set_footer(text=f"Loop: {p.loop} | Volume: {int(p.volume * 100)}%")
        await ctx.send(embed=e, view=Controls(self))

    @commands.hybrid_command(name="volume", description="Set the volume (1-100)")
    @commands.guild_only()
    async def volume(self, ctx, level: commands.Range[int, 1, 100]):
        vc = await self.check_control(ctx)
        if vc is None:
            return
        p = self.player(ctx.guild.id)
        p.volume = level / 100
        if isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = p.volume
        await ctx.send(embed=helpers.ok(f"🔊 Volume set to **{level}%**."))

    @commands.hybrid_command(name="loop", description="Loop the song, the whole queue, or nothing")
    @commands.guild_only()
    async def loop(self, ctx, mode: Optional[Literal["off", "one", "all"]] = None):
        """mode: off, one (current song) or all (whole queue). Leave empty to cycle."""
        if await self.check_control(ctx) is None:
            return
        p = self.player(ctx.guild.id)
        if mode is None:
            p.loop = {"off": "one", "one": "all", "all": "off"}[p.loop]
        else:
            p.loop = mode
        await ctx.send(embed=helpers.ok(f"🔁 Loop: **{p.loop}**"))

    @commands.hybrid_command(name="shuffle", description="Shuffle the queue")
    @commands.guild_only()
    async def shuffle(self, ctx):
        if await self.check_control(ctx) is None:
            return
        p = self.player(ctx.guild.id)
        if len(p.queue) < 2:
            return await ctx.send(embed=helpers.err("Not enough songs to shuffle."), ephemeral=True)
        random.shuffle(p.queue)
        await ctx.send(embed=helpers.ok("🔀 Queue shuffled."))

    @commands.hybrid_command(name="remove", description="Remove a song from the queue by its number")
    @commands.guild_only()
    async def remove(self, ctx, position: commands.Range[int, 1, 500]):
        if await self.check_control(ctx) is None:
            return
        p = self.player(ctx.guild.id)
        if position > len(p.queue):
            return await ctx.send(embed=helpers.err("There's no song at that position."), ephemeral=True)
        track = p.queue.pop(position - 1)
        await ctx.send(embed=helpers.ok(f"Removed **{track.title}**."))

    @commands.hybrid_command(name="clear", description="Clear the queue (keeps the current song)")
    @commands.guild_only()
    async def clear(self, ctx):
        if await self.check_control(ctx) is None:
            return
        self.player(ctx.guild.id).queue.clear()
        await ctx.send(embed=helpers.ok("Queue cleared."))

    @commands.hybrid_command(name="join", description="Make the bot join your voice channel")
    @commands.guild_only()
    async def join(self, ctx):
        vc = await self.ensure_voice(ctx)
        if vc is not None:
            await ctx.send(embed=helpers.ok(f"Joined {vc.channel.mention}."))

    @commands.hybrid_command(name="leave", description="Make the bot leave the voice channel")
    @commands.guild_only()
    async def leave(self, ctx):
        vc = await self.check_control(ctx)
        if vc is None:
            return
        self.player(ctx.guild.id).queue.clear()
        await vc.disconnect()
        await ctx.send(embed=helpers.ok("👋 Left the voice channel."))

    # ------------------------------------------------------------------- events
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        guild = member.guild
        if member.id == self.bot.user.id and after.channel is None:
            p = self.players.pop(guild.id, None)
            if p is not None:
                self.cancel_idle(p)
            return

        vc = guild.voice_client
        if vc is None or vc.channel is None:
            return
        if before.channel == vc.channel and after.channel != vc.channel:
            if not [m for m in vc.channel.members if not m.bot]:
                await asyncio.sleep(60)  # wait a minute in case someone comes back
                vc = guild.voice_client
                if vc is not None and vc.channel is not None and not [m for m in vc.channel.members if not m.bot]:
                    self.player(guild.id).queue.clear()
                    await vc.disconnect()


async def setup(bot):
    await bot.add_cog(Music(bot))
