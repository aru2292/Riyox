import asyncio
import time
from collections import defaultdict, deque
from typing import Literal, Optional

import discord
from discord.ext import commands

from utils import helpers

# Permissions that are dangerous to hand out. Giving these to a role (or giving a
# role that has them) without being whitelisted is treated as an attack.
DANGEROUS = discord.Permissions(
    administrator=True,
    manage_guild=True,
    manage_roles=True,
    manage_channels=True,
    ban_members=True,
    kick_members=True,
    manage_webhooks=True,
    mention_everyone=True,
).value

ActionName = Literal[
    "ban",
    "kick",
    "channel_delete",
    "channel_create",
    "role_delete",
    "role_create",
    "webhook_create",
    "bot_add",
    "role_update",
    "role_grant",
]


class AntiNuke(commands.Cog, name="AntiNuke"):
    """Stops mass bans, channel/role wipes, rogue webhooks and unknown bots."""

    def __init__(self, bot):
        self.bot = bot
        self.hits = defaultdict(deque)  # (guild, user, action) -> timestamps
        self.punished = {}  # (guild, user) -> last punish time
        self.created = defaultdict(list)  # (guild, user, kind) -> objects to clean up
        self.seen_entries = set()  # audit log entry ids already handled

    # ------------------------------------------------------------------ helpers
    def cfg(self, guild):
        return self.bot.store.get(guild.id)["antinuke"]

    def active(self, guild):
        return self.cfg(guild)["enabled"]

    def trusted(self, guild, user_id):
        return (
            user_id == guild.owner_id
            or user_id == self.bot.user.id
            or user_id in self.cfg(guild)["whitelist"]
        )

    async def find_entry(self, guild, action, target_id=None, within=15, tries=3, dedupe=False):
        """Find who did something by reading the audit log."""
        if not guild.me.guild_permissions.view_audit_log:
            return None
        for attempt in range(tries):
            try:
                async for entry in guild.audit_logs(limit=10, action=action):
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if age > within:
                        break
                    if target_id is not None and getattr(entry.target, "id", None) != target_id:
                        continue
                    if dedupe:
                        if entry.id in self.seen_entries:
                            continue
                        self.seen_entries.add(entry.id)
                        if len(self.seen_entries) > 500:
                            self.seen_entries.clear()
                    return entry
            except discord.HTTPException:
                return None
            if attempt < tries - 1:
                await asyncio.sleep(1)
        return None

    async def log(self, guild, title, description, color=0xE74C3C):
        e = discord.Embed(
            title=f"🛡️ {title}",
            description=description,
            color=color,
            timestamp=discord.utils.utcnow(),
        )
        channel_id = self.cfg(guild)["log_channel"]
        channel = guild.get_channel(channel_id) if channel_id else None
        try:
            if channel is not None:
                await channel.send(embed=e)
            elif guild.owner is not None:
                await guild.owner.send(embed=e)
        except discord.HTTPException:
            pass

    async def punish(self, guild, user, reason):
        key = (guild.id, user.id)
        if time.monotonic() - self.punished.get(key, 0) < 30:
            return
        self.punished[key] = time.monotonic()

        mode = self.cfg(guild)["punishment"]
        member = guild.get_member(user.id)
        result = "nothing done"
        try:
            if mode == "ban":
                await guild.ban(discord.Object(id=user.id), reason=reason)
                result = "banned"
            elif mode == "kick" and member is not None:
                await member.kick(reason=reason)
                result = "kicked"
            elif mode == "strip" and member is not None:
                keep = [
                    r
                    for r in member.roles
                    if not r.is_default() and (r.managed or r >= guild.me.top_role)
                ]
                await member.edit(roles=keep, reason=reason)
                result = "all roles removed"
        except discord.HTTPException as exc:
            result = f"FAILED ({exc.text or exc.status}). Move my role to the very top of the role list!"
        await self.log(
            guild,
            "Attacker punished",
            f"**User:** {user} (`{user.id}`)\n**Reason:** {reason}\n**Result:** {result}",
        )

    async def register(self, guild, user, action):
        """Count an action. Returns True if the user hit the limit and was punished."""
        cfg = self.cfg(guild)
        if not cfg["enabled"] or user is None or self.trusted(guild, user.id):
            return False
        now = time.monotonic()
        dq = self.hits[(guild.id, user.id, action)]
        dq.append(now)
        while dq and now - dq[0] > cfg["window"]:
            dq.popleft()
        limit = cfg["limits"].get(action, 3)
        if len(dq) >= limit:
            dq.clear()
            await self.punish(guild, user, f"Anti-nuke: {action} x{limit} within {cfg['window']}s")
            return True
        return False

    async def cleanup(self, guild, user_id, kind):
        for obj in self.created.pop((guild.id, user_id, kind), []):
            try:
                await obj.delete(reason="Anti-nuke: cleaning up attacker's creations")
            except discord.HTTPException:
                pass

    # ------------------------------------------------------------------- events
    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        if not self.active(guild):
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.ban, user.id)
        if entry and entry.user:
            await self.register(guild, entry.user, "ban")

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        guild = member.guild
        if not self.active(guild) or member.id == self.bot.user.id:
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.kick, member.id, within=10, tries=2)
        if entry and entry.user:
            await self.register(guild, entry.user, "kick")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        guild = channel.guild
        if not self.active(guild):
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.channel_delete, channel.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        if self.cfg(guild)["restore_channels"]:
            try:
                new = await channel.clone(reason="Anti-nuke: restoring deleted channel")
                try:
                    await new.edit(position=channel.position)
                except discord.HTTPException:
                    pass
                await self.log(
                    guild,
                    "Channel restored",
                    f"**#{channel.name}** was deleted by {entry.user.mention} and has been recreated.",
                    0xF39C12,
                )
            except discord.HTTPException:
                pass
        await self.register(guild, entry.user, "channel_delete")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        guild = channel.guild
        if not self.active(guild):
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.channel_create, channel.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        self.created[(guild.id, entry.user.id, "channel")].append(channel)
        if await self.register(guild, entry.user, "channel_create"):
            await self.cleanup(guild, entry.user.id, "channel")

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        guild = role.guild
        if not self.active(guild) or role.managed:
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.role_create, role.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        self.created[(guild.id, entry.user.id, "role")].append(role)
        if await self.register(guild, entry.user, "role_create"):
            await self.cleanup(guild, entry.user.id, "role")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        guild = role.guild
        if not self.active(guild) or role.managed:
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.role_delete, role.id)
        if entry and entry.user:
            await self.register(guild, entry.user, "role_delete")

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        guild = after.guild
        if not self.active(guild):
            return
        gained = after.permissions.value & ~before.permissions.value & DANGEROUS
        if not gained:
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.role_update, after.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        try:
            await after.edit(permissions=before.permissions, reason="Anti-nuke: reverting dangerous permissions")
            await self.log(
                guild,
                "Role permissions reverted",
                f"{entry.user.mention} gave dangerous permissions to {after.mention}. Change was undone.",
                0xF39C12,
            )
        except discord.HTTPException:
            pass
        await self.register(guild, entry.user, "role_update")

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.roles == after.roles:
            return
        guild = after.guild
        if not self.active(guild):
            return
        added = [r for r in after.roles if r not in before.roles]
        bad = [r for r in added if r.permissions.value & DANGEROUS]
        if not bad:
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.member_role_update, after.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        try:
            await after.remove_roles(*bad, reason="Anti-nuke: dangerous role given by non-whitelisted user")
            await self.log(
                guild,
                "Dangerous role removed",
                f"{entry.user.mention} gave {', '.join(r.mention for r in bad)} to {after.mention}. Roles removed.",
                0xF39C12,
            )
        except discord.HTTPException:
            pass
        await self.register(guild, entry.user, "role_grant")

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        guild = channel.guild
        if not self.active(guild):
            return
        entry = await self.find_entry(
            guild, discord.AuditLogAction.webhook_create, within=10, tries=2, dedupe=True
        )
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        try:
            for hook in await channel.webhooks():
                if hook.user and hook.user.id == entry.user.id:
                    await hook.delete(reason="Anti-nuke: webhook from non-whitelisted user")
        except (discord.HTTPException, AttributeError):
            pass
        await self.register(guild, entry.user, "webhook_create")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if not member.bot:
            return
        guild = member.guild
        if not self.active(guild):
            return
        entry = await self.find_entry(guild, discord.AuditLogAction.bot_add, member.id)
        if entry is None or entry.user is None or self.trusted(guild, entry.user.id):
            return
        try:
            await member.kick(reason="Anti-nuke: bot added by non-whitelisted user")
            await self.log(
                guild,
                "Unauthorized bot removed",
                f"{entry.user.mention} added **{member}**. The bot was kicked.\n"
                "Whitelist the user first if this was intended.",
                0xF39C12,
            )
        except discord.HTTPException:
            pass
        await self.register(guild, entry.user, "bot_add")

    # ----------------------------------------------------------------- commands
    @commands.hybrid_group(
        name="antinuke",
        description="Protect the server from nukes and raids",
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def antinuke(self, ctx):
        await helpers.group_help(ctx)

    @antinuke.command(name="setup", description="Turn on anti-nuke and create a private log channel")
    @helpers.guild_owner_only()
    @commands.bot_has_guild_permissions(manage_channels=True)
    async def an_setup(self, ctx):
        cfg = self.cfg(ctx.guild)
        cfg["enabled"] = True
        created = ""
        if not cfg["log_channel"] or ctx.guild.get_channel(cfg["log_channel"]) is None:
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                ctx.guild.me: discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, embed_links=True
                ),
            }
            channel = await ctx.guild.create_text_channel(
                "antinuke-logs", overwrites=overwrites, reason="Anti-nuke log channel"
            )
            cfg["log_channel"] = channel.id
            created = f"\nLog channel: {channel.mention} (only admins can see it)"
        self.bot.store.save()
        await ctx.send(
            embed=helpers.ok(
                "Anti-nuke is **ON**." + created + "\n"
                "Important: drag my role to the **very top** of Server Settings -> Roles, "
                "otherwise I can't punish attackers."
            )
        )

    @antinuke.command(name="enable", description="Turn anti-nuke on")
    @helpers.guild_owner_only()
    async def an_enable(self, ctx):
        self.cfg(ctx.guild)["enabled"] = True
        self.bot.store.save()
        await ctx.send(embed=helpers.ok("Anti-nuke enabled."))

    @antinuke.command(name="disable", description="Turn anti-nuke off")
    @helpers.guild_owner_only()
    async def an_disable(self, ctx):
        self.cfg(ctx.guild)["enabled"] = False
        self.bot.store.save()
        await ctx.send(embed=helpers.warn("Anti-nuke disabled. Your server is NOT protected."))

    @antinuke.command(name="status", description="Show anti-nuke settings and health check")
    @commands.has_permissions(administrator=True)
    async def an_status(self, ctx):
        guild = ctx.guild
        cfg = self.cfg(guild)
        e = helpers.embed("🛡️ Anti-Nuke", color=helpers.GREEN if cfg["enabled"] else helpers.RED)
        e.add_field(name="Status", value="🟢 Enabled" if cfg["enabled"] else "🔴 Disabled")
        e.add_field(name="Punishment", value=cfg["punishment"])
        e.add_field(name="Window", value=f"{cfg['window']}s")
        e.add_field(
            name="Limits (actions per window)",
            value="\n".join(f"`{k}`: {v}" for k, v in cfg["limits"].items()),
            inline=False,
        )
        e.add_field(
            name="Whitelist",
            value=", ".join(f"<@{i}>" for i in cfg["whitelist"]) or "Only the server owner",
            inline=False,
        )
        e.add_field(
            name="Restore deleted channels",
            value="Yes" if cfg["restore_channels"] else "No",
        )
        channel = guild.get_channel(cfg["log_channel"]) if cfg["log_channel"] else None
        e.add_field(name="Log channel", value=channel.mention if channel else "Not set (owner gets DMs)")

        top = guild.me.top_role
        higher = [r for r in guild.roles if r.position > top.position]
        e.add_field(
            name="My role position",
            value="✅ Highest" if not higher else "⚠️ Move my role to the top of the role list!",
            inline=False,
        )
        perms = guild.me.guild_permissions
        needed = ["view_audit_log", "ban_members", "kick_members", "manage_roles", "manage_channels", "manage_webhooks"]
        missing = [p.replace("_", " ") for p in needed if not getattr(perms, p) and not perms.administrator]
        e.add_field(
            name="My permissions",
            value="✅ All good" if not missing else "⚠️ Missing: " + ", ".join(missing),
            inline=False,
        )
        await ctx.send(embed=e)

    @antinuke.command(name="punishment", description="What happens to attackers: ban, kick or strip roles")
    @helpers.guild_owner_only()
    async def an_punishment(self, ctx, mode: Literal["ban", "kick", "strip"]):
        self.cfg(ctx.guild)["punishment"] = mode
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"Punishment set to **{mode}**."))

    @antinuke.command(name="limit", description="Set how many actions of a type trigger punishment")
    @helpers.guild_owner_only()
    async def an_limit(self, ctx, action: ActionName, count: commands.Range[int, 1, 50]):
        self.cfg(ctx.guild)["limits"][action] = count
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"`{action}` limit is now **{count}** per window."))

    @antinuke.command(name="window", description="Time window in seconds used for the limits")
    @helpers.guild_owner_only()
    async def an_window(self, ctx, seconds: commands.Range[int, 5, 300]):
        self.cfg(ctx.guild)["window"] = seconds
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"Window is now **{seconds}s**."))

    @antinuke.command(name="logchannel", description="Set (or clear) the anti-nuke log channel")
    @helpers.guild_owner_only()
    async def an_logchannel(self, ctx, channel: Optional[discord.TextChannel] = None):
        self.cfg(ctx.guild)["log_channel"] = channel.id if channel else None
        self.bot.store.save()
        text = f"Log channel set to {channel.mention}." if channel else "Log channel cleared (owner gets DMs)."
        await ctx.send(embed=helpers.ok(text))

    @antinuke.command(name="restore", description="Recreate channels deleted by non-whitelisted users")
    @helpers.guild_owner_only()
    async def an_restore(self, ctx, state: bool):
        self.cfg(ctx.guild)["restore_channels"] = state
        self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"Channel restore is now **{'on' if state else 'off'}**."))

    @antinuke.command(name="whitelist_add", description="Trust a user or bot (they can't be punished)")
    @helpers.guild_owner_only()
    async def an_wl_add(self, ctx, user: discord.User):
        wl = self.cfg(ctx.guild)["whitelist"]
        if user.id not in wl:
            wl.append(user.id)
            self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"{user.mention} is now whitelisted."))

    @antinuke.command(name="whitelist_remove", description="Remove a user or bot from the whitelist")
    @helpers.guild_owner_only()
    async def an_wl_remove(self, ctx, user: discord.User):
        wl = self.cfg(ctx.guild)["whitelist"]
        if user.id in wl:
            wl.remove(user.id)
            self.bot.store.save()
        await ctx.send(embed=helpers.ok(f"{user.mention} removed from the whitelist."))

    @antinuke.command(name="whitelist_list", description="Show whitelisted users")
    @commands.has_permissions(administrator=True)
    async def an_wl_list(self, ctx):
        wl = self.cfg(ctx.guild)["whitelist"]
        text = "\n".join(f"<@{i}> (`{i}`)" for i in wl) or "Nobody. Only the server owner is trusted."
        await ctx.send(embed=helpers.embed("Anti-nuke whitelist", text))


async def setup(bot):
    await bot.add_cog(AntiNuke(bot))
