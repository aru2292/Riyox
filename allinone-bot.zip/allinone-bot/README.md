# All-in-One Discord Bot

Antinuke + Music + Join-to-Create VC + Moderation + AutoMod + Welcome + Logs. সম্পূর্ণ ফ্রি, কোনো পেইড API লাগে না।

## কী কী আছে

| Module | কী করে |
|---|---|
| **AntiNuke** | mass ban/kick, channel/role delete, webhook, অচেনা bot add, dangerous permission দেওয়া ঠেকায়। অপরাধীকে ban/kick/strip করে, delete হওয়া channel ফেরত আনে |
| **Music** | YouTube নাম/লিংক/playlist, queue, loop, shuffle, volume, বাটন কন্ট্রোল |
| **TempVC** | Hub-এ ঢুকলেই নিজের VC তৈরি, ফাঁকা হলে অটো ডিলিট। `/vc name, limit, lock, unlock, permit, kick, transfer, claim` |
| **Moderation** | kick, ban, unban, timeout, warn, purge, slowmode, lock, addrole... |
| **AutoMod** | invite/link block, anti-spam, mass mention, bad words |
| **Welcome** | welcome message + auto-role |
| **Logs** | message delete/edit, join/leave, voice log |

সব কমান্ড slash (`/`) এবং prefix (`!`) দুইভাবেই চলে। `/help` দিলে পুরো লিস্ট দেখা যাবে।

## ধাপ ১: Bot তৈরি (Discord Developer Portal)

1. https://discord.com/developers/applications -> **New Application**
2. **Bot** ট্যাব -> **Reset Token** -> token কপি করো (কাউকে দেবে না)
3. একই পেজে নিচে **Privileged Gateway Intents** এ এই দুটো **ON** করো (না করলে bot চালু হবে না):
   - SERVER MEMBERS INTENT
   - MESSAGE CONTENT INTENT
4. **OAuth2 -> URL Generator** -> scopes: `bot` + `applications.commands`, permission: **Administrator** -> লিংকে গিয়ে সার্ভারে add করো

## ধাপ ২: GitHub Codespace এ চালানো

1. GitHub এ নতুন repo বানাও (Private রাখো)
2. Repo খুলে **Code -> Codespaces -> Create codespace**
3. এই zip টা Codespace এর বাম পাশের Explorer এ drag করে ফেলো, তারপর Terminal এ:

```bash
unzip allinone-bot.zip
cd allinone-bot
sudo apt-get update && sudo apt-get install -y ffmpeg
pip install -r requirements.txt
cp .env.example .env
```

4. বাম পাশে `.env` ফাইল খুলে `DISCORD_TOKEN=` এর পরে token বসাও, `OWNER_IDS=` এ তোমার Discord user ID দাও
5. চালাও:

```bash
python main.py
```

`Logged in as ...` দেখলে bot অনলাইন। (Slash command আসতে ১-২ মিনিট লাগতে পারে)

> `.env` আর `data/` ফোল্ডার `.gitignore` এ আছে, তাই token GitHub এ যাবে না।

## ধাপ ৩: প্রথম সেটআপ (সার্ভারে)

1. Server Settings -> Roles এ bot এর role টা **সবার উপরে** টেনে আনো (না করলে antinuke কাউকে ban করতে পারবে না)
2. `/antinuke setup` -> চালু হবে + private log channel বানাবে
3. `/antinuke whitelist_add` -> বিশ্বাসী admin আর বিশ্বাসী bot (Carl-bot, ticket bot ইত্যাদি) কে whitelist করো
4. `/vc setup` -> Join-to-Create তৈরি
5. `/welcome channel`, `/logs channel`, `/automod toggle` ইচ্ছামতো

## AntiNuke কীভাবে কাজ করে

- সার্ভার owner আর whitelist করা ইউজার **কখনো** punish হয় না। বাকি সবাই (admin সহ) নজরে থাকে
- ১৫ সেকেন্ডের মধ্যে limit পার হলে (যেমন ৩টা ban) bot অপরাধীকে ban করে। `/antinuke limit`, `/antinuke window`, `/antinuke punishment` দিয়ে বদলানো যায়
- Whitelist ছাড়া কেউ webhook বানালে সেটা মুছে যায়, bot add করলে bot kick হয়, dangerous permission (Admin, Ban, Manage Roles ইত্যাদি) দিলে সেটা revert হয়
- **সীমাবদ্ধতা:** Discord এর নিয়মে bot শুধু নিজের role এর নিচের role ওয়ালাকে ban করতে পারে। আর সার্ভার owner একাউন্ট হ্যাক হলে কোনো bot বাঁচাতে পারবে না, তাই 2FA চালু রাখো

## Music কাজ না করলে

- `ffmpeg was not found` -> `sudo apt-get install -y ffmpeg`
- `Sign in to confirm you're not a bot` -> YouTube অনেক hosting IP ব্লক করে। সমাধান: browser এ YouTube এ লগইন করে "Get cookies.txt LOCALLY" এক্সটেনশন দিয়ে `cookies.txt` export করো, bot এর ফোল্ডারে রাখো। (আলাদা একটা YouTube একাউন্ট ব্যবহার করা ভালো)
- Spotify লিংক সাপোর্ট করে না, গানের নাম লিখে `/play` দাও
- Voice এ ঢুকতে না পারলে `pip install -U "discord.py[voice]"` দিয়ে আপডেট করো

## 24/7 hosting

- Codespaces আসলে 24/7 চলে না, কিছুক্ষণ idle থাকলে বন্ধ হয়ে যায়। শুধু টেস্টের জন্য ভালো
- Docker সাপোর্ট করে এমন যেকোনো host এ `Dockerfile` দিয়ে চলবে (ffmpeg আর deno ভেতরে আছে)
- যেসব host এ web port লাগে, সেখানে Environment এ `PORT` সেট করে দাও, তাহলে bot নিজে একটা ছোট web server চালাবে

## ফাইল স্ট্রাকচার

```
main.py            bot চালু করার ফাইল
config.py          .env থেকে সেটিংস
cogs/              antinuke, music, tempvc, moderation, automod, welcome, logs, utility
utils/             storage + helper
Dockerfile         docker hosting এর জন্য
requirements.txt   pip packages
```
