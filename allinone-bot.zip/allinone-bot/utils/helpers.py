"""Shared helpers: embeds, duration parsing, permission checks."""
import re

import discord
from discord.ext import commands

import config

GREEN = 0x2ECC71
RED = 0xE74C3C
ORANGE = 0xF39C12


def embed(title=None, description=None, color=config.EMBED_COLOR):
    return discord.Embed(title=title, description=description, color=color)


def ok(text):
    return discord.Embed(description=f"✅ {text}", color=GREEN)


def err(text):
    return discord.Embed(description=f"❌ {text}", color=RED)


def warn(text):
    return discord.Embed(description=f"⚠️ {text}", color=ORANGE)


def fmt_duration(seconds):
    if not seconds:
        return "Live / unknown"
    seconds = int(seconds)
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


_DUR = re.compile(r"(\d+)\s*([smhdw])", re.I)
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(text):
    """'1h30m' -> 5400 seconds. Returns None if nothing valid was found."""
    found = _DUR.findall(text or "")
    if not found:
        return None
    return sum(int(n) * _UNITS[u.lower()] for n, u in found)


async def send_log(bot, guild, log_embed):
    """Send an embed to the server's log channel (if one is set)."""
    channel_id = bot.store.get(guild.id)["logs"]["channel"]
    channel = guild.get_channel(channel_id) if channel_id else None
    if channel is None:
        return
    try:
        await channel.send(embed=log_embed)
    except discord.HTTPException:
        pass


def guild_owner_only():
    """Command check: only the server owner (or a bot owner from OWNER_IDS)."""

    async def predicate(ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id in config.OWNER_IDS:
            return True
        raise commands.CheckFailure("Only the server owner can use this command.")

    return commands.check(predicate)


def can_moderate(ctx, target):
    """Return a problem description if ctx.author can't act on target, else None."""
    guild = ctx.guild
    if target.id == ctx.author.id:
        return "You can't do that to yourself."
    if target.id == guild.owner_id:
        return "You can't do that to the server owner."
    if target.id == guild.me.id:
        return "I won't do that to myself."
    if ctx.author.id != guild.owner_id and target.top_role >= ctx.author.top_role:
        return "That member's top role is equal to or higher than yours."
    if target.top_role >= guild.me.top_role:
        return "That member's top role is equal to or higher than mine. Move my role up."
    return None


async def group_help(ctx):
    """Reply with the list of subcommands when a command group is used alone."""
    group = ctx.command
    lines = []
    for sub in sorted(group.commands, key=lambda c: c.name):
        text = sub.description or sub.short_doc or ""
        lines.append(f"`{ctx.prefix}{group.name} {sub.name}` - {text}")
    await ctx.send(embed=embed(f"{group.name} commands", "\n".join(lines) or "No subcommands."))
