"""Very small JSON-file storage for per-server settings (no database needed)."""
import copy
import json
import os

DEFAULTS = {
    "antinuke": {
        "enabled": False,
        "punishment": "ban",  # ban | kick | strip
        "window": 15,  # seconds
        "limits": {
            "ban": 3,
            "kick": 3,
            "channel_delete": 2,
            "channel_create": 4,
            "role_delete": 2,
            "role_create": 4,
            "webhook_create": 2,
            "bot_add": 2,
            "role_update": 2,
            "role_grant": 2,
        },
        "whitelist": [],
        "log_channel": None,
        "restore_channels": True,
    },
    "automod": {
        "antiinvite": False,
        "antilink": False,
        "antispam": False,
        "massmention": 0,
        "badwords": [],
    },
    "tempvc": {"hub": None, "category": None, "channels": {}},
    "welcome": {
        "channel": None,
        "message": "Welcome {user} to **{server}**! You are member #{count}.",
        "autorole": None,
    },
    "logs": {"channel": None},
    "warnings": {},
}


def _fill(target, defaults):
    """Add any missing keys (recursively) so old save files keep working."""
    for key, value in defaults.items():
        if key not in target:
            target[key] = copy.deepcopy(value)
        elif isinstance(value, dict) and isinstance(target[key], dict):
            _fill(target[key], value)


class Store:
    def __init__(self, path="data/guilds.json"):
        self.path = path
        self.data = {}
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
            except ValueError:
                os.replace(path, path + ".bak")  # keep the broken file, start fresh
                self.data = {}
            except OSError:
                self.data = {}

    def get(self, guild_id):
        """Return the live settings dict for a server. Mutate it, then call save()."""
        guild = self.data.setdefault(str(guild_id), {})
        _fill(guild, DEFAULTS)
        return guild

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2)
        os.replace(tmp, self.path)
