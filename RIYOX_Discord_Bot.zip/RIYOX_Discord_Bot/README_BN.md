# ✨ RIYOX — Discord Music, Premium & Security Bot

Riyox is a modular `discord.py` bot with music playback, premium-gated Autoplay and 24/7 voice mode, per-server dashboard branding, Anti-Nuke alerts, Anti-Prune monitoring, consent-based DMs, media forwarding and settings export.

## 1) Discord Developer Portal setup
1. Create an application at https://discord.com/developers/applications.
2. Add a Bot and copy its token privately.
3. In Bot > Privileged Gateway Intents, enable **Message Content Intent** and **Server Members Intent**.
4. Invite the bot with `bot` scope and permissions: View Channels, Send Messages, Embed Links, Attach Files, Read Message History, View Audit Log, Connect, Speak. Manage Messages is needed only for the media command.
5. Do not give Administrator unless you understand why it is needed. Keep Riyox's role below the server owner and above roles it needs to manage.

## 2) Run in GitHub Codespaces
1. Upload/extract this folder into a GitHub repository and open it in Codespaces.
2. In the terminal run:
   ```bash
   pip install -r requirements.txt
   cp .env.example .env
   ```
3. Edit `.env` and put your bot token after `DISCORD_TOKEN=`.
4. Start:
   ```bash
   python bot.py
   ```
5. In a server, type `&panel` or `&help`.

Never upload `.env` or your bot token to GitHub. If a token is exposed, reset it in Discord Developer Portal immediately.

## 3) Railway hosting
1. Push the project to GitHub.
2. Create a Railway project from the repository.
3. Add Variables: `DISCORD_TOKEN`, `COMMAND_PREFIX`=`&`, and `DATABASE_PATH`=`/data/riyox.sqlite3`.
4. Add a persistent Volume mounted at `/data`.
5. Start command: `python bot.py`. Keep one replica.
6. Check Railway's current pricing and usage limits before relying on 24/7 operation; free usage or trial terms can change.

The included Nixpacks config installs FFmpeg. The bot can only stay online while its hosting process is running and connected to Discord. A 24/7 voice setting cannot prevent host outages, restarts, network loss or Discord disconnects.

## 4) Music commands
- `&play <song name or URL>` — search and play audio
- `&skip`
- `&queue`
- `&pause`
- `&resume`
- `&stop`
- `&autoplay on` / `&autoplay off` — Premium
- `&247 on` / `&247 off` — Premium; bot joins your current voice channel and attempts to remain connected while running

Music uses yt-dlp to resolve playable streams and FFmpeg to play them. Search/provider availability can change; some URLs may fail. Use music only where you have the right to play/share the audio and follow the source service's terms. This bot does not download or store music files.

## 5) Premium controls
Bot owner ID is configured in `bot.py`:
`499671679803457551`

Only that Discord account can grant/revoke premium:
- `&premium grant @user 30` — 30 days (days optional; default 30)
- `&premium revoke @user`
- `&premium list`

Premium is granted to a user account. In a server where that user is a member, that user can use Premium features. Premium features:
- `&autoplay on/off`
- `&247 on/off`
- Server-specific Riyox embed branding

Premium user must have Manage Server to customize a server's Riyox branding, unless they are the actual server owner. A server owner with premium can customize their server. The bot owner has access in every server.

## 6) Server branding
- `&brand name <display name>`
- `&brand icon <https image URL>`
- `&brand cover <https image URL>`
- `&brand reset`

This customizes the Riyox embeds/dashboard in that server using the server's chosen display name, icon and cover. It does **not** change the actual Discord server name, icon or banner.

## 7) Security & utilities
- `&antinuke enable` / `&antinuke disable`
- `&antinuke limit channel_delete 2`
- `&antinuke limit role_delete 2`
- `&antinuke limit member_ban 2`
- `&antinuke whitelist add @user` / `remove`
- `&antinuke extraowner add @user` / `remove` (actual server owner only)
- `&antinuke logchannel #channel`
- `&antiprune enable` / `disable`
- `&dm optin` / `&dm optout`
- `&dm perm @user 2 month`
- `&dm revoke @user`
- `&dm send @user <message>`
- `&media send #channel` (attach files to the command message)
- `&backup export`

## 8) Important safety and technical limits
- Anti-Nuke is audit-log based alerting for channel deletion, role deletion and bans. It does not guarantee prevention and does not automatically punish users. Configure a log channel and give Riyox View Audit Log.
- Anti-Prune can report prune audit events Discord exposes; it cannot reliably identify every removed member.
- A bot cannot outrank the actual server owner or bypass Discord permission hierarchy.
- DM sender permission is not recipient consent. Recipients must run `&dm optin`; `&dm optout` stops these bot DMs. No unsolicited bulk DM.
- `&backup export` exports Riyox configuration only, not server messages, roles, channels or a complete server restore.
- Music queue is in memory and clears on process restart. Premium and settings are in SQLite; use a persistent Railway Volume.
- Test in a private server before using in a community. This starter has been syntax-checked, not live-tested against your Discord server or Railway account.
