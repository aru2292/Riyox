import os, sqlite3, time, json, io, logging, asyncio, random
from datetime import datetime, timezone, timedelta
from collections import defaultdict, deque

import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv
import yt_dlp

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("COMMAND_PREFIX", "&")
BOT_OWNER_ID = 499671679803457551
DB_PATH = os.getenv("DATABASE_PATH", "riyox.sqlite3")
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing. Put it in .env locally or Railway Variables.")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("riyox")

db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE IF NOT EXISTS settings(guild INTEGER, key TEXT, value TEXT, PRIMARY KEY(guild,key));
CREATE TABLE IF NOT EXISTS whitelist(guild INTEGER, user INTEGER, PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS extraowners(guild INTEGER, user INTEGER, PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS dmperm(guild INTEGER, user INTEGER, expires INTEGER, PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS optins(guild INTEGER, user INTEGER, yes INTEGER, PRIMARY KEY(guild,user));
CREATE TABLE IF NOT EXISTS events(guild INTEGER, module TEXT, actor INTEGER, ts INTEGER);
CREATE TABLE IF NOT EXISTS premiums(user INTEGER PRIMARY KEY, expires INTEGER);
""")
db.commit()

def get_setting(g, k, default=""):
    row = db.execute("SELECT value FROM settings WHERE guild=? AND key=?", (g, k)).fetchone()
    return row["value"] if row else str(default)

def set_setting(g, k, value):
    db.execute("INSERT INTO settings VALUES(?,?,?) ON CONFLICT(guild,key) DO UPDATE SET value=excluded.value",
               (g, k, str(value)))
    db.commit()

def premium_expiry(user_id):
    row = db.execute("SELECT expires FROM premiums WHERE user=?", (user_id,)).fetchone()
    return int(row["expires"]) if row else 0

def is_premium_user(user_id):
    return user_id == BOT_OWNER_ID or premium_expiry(user_id) > int(time.time())

def is_server_owner_or_admin(member):
    return bool(member and member.guild and (
        member.id == member.guild.owner_id or member.guild_permissions.administrator
    ))

def has_premium_access(ctx):
    return bool(ctx.guild and (is_premium_user(ctx.author.id) or ctx.guild.owner_id == BOT_OWNER_ID))

def can_manage_brand(ctx):
    return bool(ctx.guild and (ctx.guild.owner_id == ctx.author.id or
        (ctx.author.guild_permissions.manage_guild and has_premium_access(ctx))))

def is_trusted(guild_id, user_id):
    if user_id == BOT_OWNER_ID:
        return True
    return db.execute("SELECT 1 FROM whitelist WHERE guild=? AND user=?", (guild_id,user_id)).fetchone() is not None or \
           db.execute("SELECT 1 FROM extraowners WHERE guild=? AND user=?", (guild_id,user_id)).fetchone() is not None

def make_embed(guild, title, description="", color=discord.Color.blurple()):
    e = discord.Embed(title=title, description=description, color=color, timestamp=datetime.now(timezone.utc))
    if guild:
        icon = get_setting(guild.id, "brand_icon", "") or (guild.icon.url if guild.icon else None)
        cover = get_setting(guild.id, "brand_cover", "")
        brand_name = get_setting(guild.id, "brand_name", "") or guild.name
        e.set_author(name=brand_name, icon_url=icon or discord.Embed.Empty)
        if icon:
            e.set_thumbnail(url=icon)
        if cover:
            e.set_image(url=cover)
        e.set_footer(text=f"Riyox • {guild.name}")
    else:
        e.set_footer(text="Riyox • Discord Utility & Music")
    return e

async def send_log(guild, title, description):
    try:
        channel_id = int(get_setting(guild.id, "log_channel", "0") or 0)
        channel = guild.get_channel(channel_id)
        if channel:
            await channel.send(embed=make_embed(guild, title, description, discord.Color.orange()))
    except (ValueError, discord.HTTPException, discord.Forbidden):
        pass

async def find_audit_actor(guild, action):
    try:
        async for entry in guild.audit_logs(limit=6, action=action):
            if (datetime.now(timezone.utc) - entry.created_at).total_seconds() < 15:
                return entry.user
    except (discord.Forbidden, discord.HTTPException):
        pass
    return None

async def monitor_action(guild, module, action):
    if get_setting(guild.id, "antinuke", "1") != "1":
        return
    actor = await find_audit_actor(guild, action)
    if not actor:
        return
    now = int(time.time())
    db.execute("INSERT INTO events VALUES(?,?,?,?)", (guild.id,module,actor.id,now))
    db.commit()
    limit = int(get_setting(guild.id, module + "_limit", "2"))
    count = db.execute(
        "SELECT COUNT(*) n FROM events WHERE guild=? AND module=? AND actor=? AND ts>=?",
        (guild.id,module,actor.id,now-10)
    ).fetchone()["n"]
    if count >= limit and not is_trusted(guild.id, actor.id):
        await send_log(guild, "🚨 Anti-Nuke Alert",
            f"**Module:** `{module}`\n**Actor:** {actor.mention}\n**Events:** {count} in 10 seconds\n"
            "Riyox detected unusual activity. Review the audit log; no automatic punishment was applied.")

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True
intents.voice_states = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# Music state is in memory; queued tracks reset after a process restart.
music_queues = defaultdict(deque)
current_tracks = {}
autoplay_tasks = {}
voice_247 = set()
YDL_OPTIONS = {
    "format": "bestaudio/best", "noplaylist": True, "quiet": True,
    "no_warnings": True, "default_search": "ytsearch1",
    "source_address": "0.0.0.0"
}
FFMPEG_OPTIONS = {"before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                  "options": "-vn"}

def extract_track_sync(query):
    with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
        info = ydl.extract_info(query, download=False)
        if "entries" in info:
            info = next((x for x in info["entries"] if x), None)
        if not info:
            raise ValueError("No playable result found.")
        return {"title": info.get("title","Unknown title"),
                "url": info.get("url"), "webpage": info.get("webpage_url"),
                "duration": info.get("duration") or 0,
                "thumbnail": info.get("thumbnail"), "requester": None}

async def resolve_track(query):
    return await asyncio.to_thread(extract_track_sync, query)

def fmt_duration(seconds):
    if not seconds:
        return "Live/unknown"
    seconds = int(seconds)
    return f"{seconds//3600:02d}:{(seconds%3600)//60:02d}:{seconds%60:02d}" if seconds >= 3600 else f"{seconds//60:02d}:{seconds%60:02d}"

async def play_next(guild_id):
    guild = bot.get_guild(guild_id)
    if not guild:
        return
    vc = guild.voice_client
    if not vc or not vc.is_connected() or vc.is_playing() or vc.is_paused():
        return
    if music_queues[guild_id]:
        track = music_queues[guild_id].popleft()
    elif get_setting(guild_id, "autoplay", "0") == "1" and is_guild_premium(guild_id):
        previous = current_tracks.get(guild_id)
        if not previous:
            return
        try:
            track = await resolve_track(f"ytsearch1:{previous['title']} similar songs")
            if previous.get("webpage") and track.get("webpage") == previous.get("webpage"):
                track = await resolve_track(f"ytsearch1:{previous['title']} radio")
        except Exception as ex:
            log.warning("Autoplay lookup failed: %s", ex)
            return
    else:
        return
    current_tracks[guild_id] = track
    try:
        source = discord.PCMVolumeTransformer(discord.FFmpegPCMAudio(track["url"], **FFMPEG_OPTIONS), volume=0.5)
        def after_play(error):
            if error:
                log.warning("Player error: %s", error)
            fut = asyncio.run_coroutine_threadsafe(play_next(guild_id), bot.loop)
            try:
                fut.result(timeout=5)
            except Exception:
                pass
        vc.play(source, after=after_play)
        channel = vc.channel
        if channel:
            e = discord.Embed(title="🎵 Now Playing", description=f"**[{track['title']}]({track.get('webpage') or ''})**",
                              color=discord.Color.blurple())
            e.add_field(name="Duration", value=fmt_duration(track.get("duration")), inline=True)
            if track.get("thumbnail"):
                e.set_thumbnail(url=track["thumbnail"])
            await channel.send(embed=e)
    except Exception:
        log.exception("Could not start audio playback")

def is_guild_premium(guild_id):
    guild = bot.get_guild(guild_id)
    if not guild:
        return False
    return guild.owner_id == BOT_OWNER_ID or any(is_premium_user(m.id) for m in guild.members if m.id != bot.user.id)

class DashboardSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Home", value="home", emoji="🏠"),
            discord.SelectOption(label="Music", value="music", emoji="🎵"),
            discord.SelectOption(label="Premium", value="premium", emoji="💎"),
            discord.SelectOption(label="Branding", value="brand", emoji="🎨"),
            discord.SelectOption(label="Anti-Nuke", value="nuke", emoji="🛡️"),
            discord.SelectOption(label="Anti-Prune", value="prune", emoji="🔒"),
            discord.SelectOption(label="DM Center", value="dm", emoji="✉️"),
            discord.SelectOption(label="Media", value="media", emoji="🖼️"),
            discord.SelectOption(label="Logs & Backup", value="backup", emoji="💾")
        ]
        super().__init__(placeholder="Riyox Dashboard • Select a category", min_values=1, max_values=1, options=options)

    async def callback(self, interaction):
        guild = interaction.guild
        if not guild:
            return await interaction.response.send_message("Use this panel inside a server.", ephemeral=True)
        page = self.values[0]
        pages = {
            "home": ("✨ Riyox • Dashboard",
                f"**Server:** {guild.name}\n**Anti-Nuke:** {'ON' if get_setting(guild.id,'antinuke','1')=='1' else 'OFF'}\n"
                f"**Anti-Prune:** {'ON' if get_setting(guild.id,'antiprune','1')=='1' else 'OFF'}\n"
                f"**Premium:** {'ACTIVE' if is_guild_premium(guild.id) else 'Not active'}\n\nUse `{PREFIX}help` for commands."),
            "music": ("🎵 Music Center",
                f"`{PREFIX}play <song or URL>` • `{PREFIX}skip` • `{PREFIX}queue` • `{PREFIX}pause` • `{PREFIX}resume` • `{PREFIX}stop`\n"
                f"Premium: `{PREFIX}autoplay on/off` and `{PREFIX}247 on/off`.\nRequires FFmpeg and bot Connect/Speak permissions."),
            "premium": ("💎 Riyox Premium",
                "Premium can be granted only by the bot owner. Premium users can enable Autoplay and 24/7 voice mode and customize Riyox branding in servers where they have Manage Server."),
            "brand": ("🎨 Server Branding",
                f"`{PREFIX}brand name <text>`\n`{PREFIX}brand icon <image URL>`\n`{PREFIX}brand cover <image URL>`\n`{PREFIX}brand reset`\n"
                "Changes Riyox embeds and dashboard appearance for this server, not the actual Discord server profile."),
            "nuke": ("🛡️ Anti-Nuke",
                f"`{PREFIX}antinuke enable/disable`\n`{PREFIX}antinuke limit channel_delete 2`\n`{PREFIX}antinuke limit role_delete 2`\n`{PREFIX}antinuke limit member_ban 2`\n"
                f"`{PREFIX}antinuke whitelist add/remove @user`\n`{PREFIX}antinuke extraowner add/remove @user`\n`{PREFIX}antinuke logchannel #channel`\nDetection and alerts only."),
            "prune": ("🔒 Anti-Prune",
                f"`{PREFIX}antiprune enable/disable`\nReports prune audit events Discord makes available; it cannot guarantee identification of every removed member."),
            "dm": ("✉️ DM Center",
                f"`{PREFIX}dm optin` / `{PREFIX}dm optout`\n`{PREFIX}dm perm @user 2 month`\n`{PREFIX}dm revoke @user`\n`{PREFIX}dm send @user <message>`\nRecipients must opt in. No unsolicited bulk messaging."),
            "media": ("🖼️ Media Tools",
                f"Attach files to `{PREFIX}media send #channel`. Requires Manage Messages for command user and Attach Files permission for Riyox."),
            "backup": ("💾 Logs & Backup",
                f"`{PREFIX}antinuke logchannel #channel`\n`{PREFIX}backup export`\nExports Riyox configuration only, not the complete Discord server.")
        }
        title, desc = pages[page]
        e = make_embed(guild, title, desc)
        await interaction.response.edit_message(embed=e, view=self.view)

class Dashboard(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)
        self.add_item(DashboardSelect())

@bot.event
async def on_ready():
    log.info("Riyox online as %s (%s)", bot.user, bot.user.id)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name=f"{PREFIX}play • Riyox Music"))
    if not premium_expiry_cleanup.is_running():
        premium_expiry_cleanup.start()

@tasks.loop(hours=1)
async def premium_expiry_cleanup():
    db.execute("DELETE FROM premiums WHERE expires<=?", (int(time.time()),))
    db.commit()

@bot.command()
@commands.guild_only()
async def panel(ctx):
    await ctx.send(embed=make_embed(ctx.guild, "✨ Riyox • Control Panel",
        "Choose a category below to open Music, Premium, Branding, Security and Utility modules."), view=Dashboard())

@bot.command()
async def help(ctx):
    g = ctx.guild
    text = (
        f"**Dashboard** `{PREFIX}panel`\n"
        f"**Music** `{PREFIX}play <song/URL>`, `{PREFIX}skip`, `{PREFIX}queue`, `{PREFIX}pause`, `{PREFIX}resume`, `{PREFIX}stop`\n"
        f"**Premium Music** `{PREFIX}autoplay on/off`, `{PREFIX}247 on/off`\n"
        f"**Premium Admin** `{PREFIX}premium grant @user [days]`, `{PREFIX}premium revoke @user`, `{PREFIX}premium list`\n"
        f"**Branding** `{PREFIX}brand name/icon/cover/reset`\n"
        f"**Security** `{PREFIX}antinuke ...`, `{PREFIX}antiprune enable/disable`\n"
        f"**DM** `{PREFIX}dm optin/optout/perm/revoke/send`\n"
        f"**Media** `{PREFIX}media send #channel`\n"
        f"**Backup** `{PREFIX}backup export`\n"
    )
    await ctx.reply(embed=make_embed(g, "📚 Riyox Commands", text))

# Premium owner controls
@bot.group(invoke_without_command=True)
async def premium(ctx):
    if ctx.author.id != BOT_OWNER_ID:
        return await ctx.reply("Only Riyox Bot Owner can manage Premium.")
    await ctx.reply(f"`{PREFIX}premium grant @user [days]` • `{PREFIX}premium revoke @user` • `{PREFIX}premium list`")

@premium.command()
async def grant(ctx, member: discord.User, days: int = 30):
    if ctx.author.id != BOT_OWNER_ID:
        return await ctx.reply("⛔ Only Riyox Bot Owner can grant Premium.")
    if not 1 <= days <= 3650:
        return await ctx.reply("Days must be between 1 and 3650.")
    expiry = int((datetime.now(timezone.utc) + timedelta(days=days)).timestamp())
    db.execute("INSERT INTO premiums VALUES(?,?) ON CONFLICT(user) DO UPDATE SET expires=excluded.expires",
               (member.id, expiry))
    db.commit()
    await ctx.reply(f"💎 Premium granted to {member.mention} until <t:{expiry}:F>.")

@premium.command()
async def revoke(ctx, member: discord.User):
    if ctx.author.id != BOT_OWNER_ID:
        return await ctx.reply("⛔ Only Riyox Bot Owner can revoke Premium.")
    db.execute("DELETE FROM premiums WHERE user=?", (member.id,))
    db.commit()
    await ctx.reply(f"Premium revoked for {member.mention}.")

@premium.command(name="list")
async def premium_list(ctx):
    if ctx.author.id != BOT_OWNER_ID:
        return await ctx.reply("⛔ Only Riyox Bot Owner can view this list.")
    rows = db.execute("SELECT user,expires FROM premiums ORDER BY expires DESC").fetchall()
    if not rows:
        return await ctx.reply("No active Premium grants.")
    lines = [f"<@{r['user']}> — <t:{r['expires']}:R>" for r in rows[:40] if r["expires"] > int(time.time())]
    await ctx.reply(embed=make_embed(ctx.guild, "💎 Premium Users", "\n".join(lines) or "No active grants."))

# Per-server Riyox branding
@bot.group(invoke_without_command=True)
@commands.guild_only()
async def brand(ctx):
    await ctx.reply(f"`{PREFIX}brand name <text>` • `{PREFIX}brand icon <https image URL>` • `{PREFIX}brand cover <https image URL>` • `{PREFIX}brand reset`")

@brand.command()
@commands.guild_only()
async def name(ctx, *, value: str):
    if not can_manage_brand(ctx):
        return await ctx.reply("Premium access and Manage Server permission (or server ownership) are required.")
    value = value.strip()[:80]
    if not value:
        return await ctx.reply("Brand name cannot be empty.")
    set_setting(ctx.guild.id, "brand_name", value)
    await ctx.reply(embed=make_embed(ctx.guild, "🎨 Branding Updated", f"Display name set to **{value}**."))

@brand.command()
@commands.guild_only()
async def icon(ctx, *, url: str):
    if not can_manage_brand(ctx):
        return await ctx.reply("Premium access and Manage Server permission (or server ownership) are required.")
    if not url.startswith("https://") or len(url) > 500:
        return await ctx.reply("Use a valid HTTPS image URL.")
    set_setting(ctx.guild.id, "brand_icon", url.strip())
    await ctx.reply(embed=make_embed(ctx.guild, "🎨 Icon Updated", "Riyox server branding icon updated."))

@brand.command()
@commands.guild_only()
async def cover(ctx, *, url: str):
    if not can_manage_brand(ctx):
        return await ctx.reply("Premium access and Manage Server permission (or server ownership) are required.")
    if not url.startswith("https://") or len(url) > 500:
        return await ctx.reply("Use a valid HTTPS image URL.")
    set_setting(ctx.guild.id, "brand_cover", url.strip())
    await ctx.reply(embed=make_embed(ctx.guild, "🎨 Cover Updated", "Riyox server branding cover updated."))

@brand.command()
@commands.guild_only()
async def reset(ctx):
    if not can_manage_brand(ctx):
        return await ctx.reply("Premium access and Manage Server permission (or server ownership) are required.")
    for key in ("brand_name","brand_icon","brand_cover"):
        db.execute("DELETE FROM settings WHERE guild=? AND key=?", (ctx.guild.id,key))
    db.commit()
    await ctx.reply(embed=make_embed(ctx.guild, "🎨 Branding Reset", "Riyox branding restored to server defaults."))

# Music commands
async def ensure_voice(ctx):
    if not ctx.author.voice or not ctx.author.voice.channel:
        await ctx.reply("Join a voice channel first.")
        return None
    channel = ctx.author.voice.channel
    vc = ctx.guild.voice_client
    try:
        if vc and vc.is_connected():
            if vc.channel != channel:
                await vc.move_to(channel)
        else:
            vc = await channel.connect(timeout=20, reconnect=True)
        return vc
    except (discord.Forbidden, discord.HTTPException, asyncio.TimeoutError):
        await ctx.reply("Could not join voice. Check Connect/Speak permissions.")
        return None

@bot.command()
@commands.guild_only()
async def play(ctx, *, query: str):
    vc = await ensure_voice(ctx)
    if not vc:
        return
    await ctx.typing()
    try:
        track = await resolve_track(query)
        track["requester"] = ctx.author.id
        music_queues[ctx.guild.id].append(track)
        if not vc.is_playing() and not vc.is_paused():
            await play_next(ctx.guild.id)
        else:
            await ctx.reply(embed=make_embed(ctx.guild, "➕ Added to Queue",
                f"**{track['title']}**\nDuration: {fmt_duration(track['duration'])}\nPosition: {len(music_queues[ctx.guild.id])}"))
    except Exception as ex:
        log.warning("Track resolve failed: %s", ex)
        await ctx.reply("Couldn't find/play that track. Try a direct supported URL or a different search.")

@bot.command()
@commands.guild_only()
async def skip(ctx):
    vc = ctx.guild.voice_client
    if not vc or not vc.is_playing():
        return await ctx.reply("Nothing is playing.")
    vc.stop()
    await ctx.reply("⏭️ Skipped.")

@bot.command()
@commands.guild_only()
async def queue(ctx):
    items = list(music_queues[ctx.guild.id])
    current = current_tracks.get(ctx.guild.id)
    lines = [f"▶️ **Now:** {current['title']}" ] if current else []
    lines += [f"`{i}.` {t['title']} · {fmt_duration(t['duration'])}" for i,t in enumerate(items[:10],1)]
    await ctx.reply(embed=make_embed(ctx.guild, "🎶 Music Queue", "\n".join(lines) or "Queue is empty."))

@bot.command()
@commands.guild_only()
async def pause(ctx):
    vc = ctx.guild.voice_client
    if vc and vc.is_playing():
        vc.pause()
        return await ctx.reply("⏸️ Paused.")
    await ctx.reply("Nothing is playing.")

@bot.command()
@commands.guild_only()
async def resume(ctx):
    vc = ctx.guild.voice_client
    if vc and vc.is_paused():
        vc.resume()
        return await ctx.reply("▶️ Resumed.")
    await ctx.reply("Nothing is paused.")

@bot.command()
@commands.guild_only()
async def stop(ctx):
    vc = ctx.guild.voice_client
    music_queues[ctx.guild.id].clear()
    if vc:
        vc.stop()
    current_tracks.pop(ctx.guild.id, None)
    await ctx.reply("⏹️ Playback stopped and queue cleared.")

@bot.command()
@commands.guild_only()
async def autoplay(ctx, mode: str):
    if not has_premium_access(ctx):
        return await ctx.reply("💎 Autoplay is a Premium feature.")
    if mode.lower() not in ("on","off"):
        return await ctx.reply(f"Use `{PREFIX}autoplay on` or `{PREFIX}autoplay off`.")
    set_setting(ctx.guild.id, "autoplay", "1" if mode.lower()=="on" else "0")
    await ctx.reply(f"🎵 Autoplay **{mode.upper()}**.")

@bot.command(name="247")
@commands.guild_only()
async def always_247(ctx, mode: str):
    if not has_premium_access(ctx):
        return await ctx.reply("💎 24/7 voice mode is a Premium feature.")
    if mode.lower() not in ("on","off"):
        return await ctx.reply(f"Use `{PREFIX}247 on` or `{PREFIX}247 off`.")
    if mode.lower() == "on":
        vc = await ensure_voice(ctx)
        if not vc:
            return
        voice_247.add(ctx.guild.id)
        set_setting(ctx.guild.id, "247", "1")
        await ctx.reply("♾️ 24/7 mode enabled. Riyox will try to remain in this voice channel while the bot process is online.")
    else:
        voice_247.discard(ctx.guild.id)
        set_setting(ctx.guild.id, "247", "0")
        vc = ctx.guild.voice_client
        if vc:
            await vc.disconnect(force=True)
        await ctx.reply("24/7 mode disabled; Riyox left the voice channel.")

# Security modules
@bot.group(invoke_without_command=True)
@commands.guild_only()
async def antinuke(ctx):
    await ctx.reply("Use enable/disable, limit, whitelist, extraowner or logchannel.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def enable(ctx):
    set_setting(ctx.guild.id,"antinuke","1")
    await ctx.reply("🛡️ Anti-Nuke monitoring enabled.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def disable(ctx):
    set_setting(ctx.guild.id,"antinuke","0")
    await ctx.reply("Anti-Nuke monitoring disabled.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def limit(ctx, module: str, count: int):
    if module not in {"channel_delete","role_delete","member_ban"} or not 1 <= count <= 20:
        return await ctx.reply("Valid modules: channel_delete, role_delete, member_ban; limit 1–20.")
    set_setting(ctx.guild.id,module+"_limit",count)
    await ctx.reply(f"Limit set: `{module}` = {count} per 10 seconds.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def whitelist(ctx, action: str, member: discord.Member):
    if action.lower()=="add":
        db.execute("INSERT OR IGNORE INTO whitelist VALUES(?,?)",(ctx.guild.id,member.id))
    elif action.lower()=="remove":
        db.execute("DELETE FROM whitelist WHERE guild=? AND user=?",(ctx.guild.id,member.id))
    else:
        return await ctx.reply("Use add/remove.")
    db.commit()
    await ctx.reply(f"Whitelist updated for {member.mention}.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def extraowner(ctx, action: str, member: discord.Member):
    if ctx.author.id != ctx.guild.owner_id:
        return await ctx.reply("Only the actual Discord server owner can manage extra owners.")
    if action.lower()=="add":
        db.execute("INSERT OR IGNORE INTO extraowners VALUES(?,?)",(ctx.guild.id,member.id))
    elif action.lower()=="remove":
        db.execute("DELETE FROM extraowners WHERE guild=? AND user=?",(ctx.guild.id,member.id))
    else:
        return await ctx.reply("Use add/remove.")
    db.commit()
    await ctx.reply(f"Extra-owner list updated for {member.mention}.")

@antinuke.command()
@commands.has_guild_permissions(administrator=True)
async def logchannel(ctx, channel: discord.TextChannel):
    set_setting(ctx.guild.id,"log_channel",channel.id)
    await ctx.reply(f"📜 Logs will be sent to {channel.mention}.")

@bot.group(invoke_without_command=True)
@commands.guild_only()
async def antiprune(ctx):
    await ctx.reply("Use `enable` or `disable`.")

@antiprune.command()
@commands.has_guild_permissions(administrator=True)
async def enable(ctx):
    set_setting(ctx.guild.id,"antiprune","1")
    await ctx.reply("🔒 Anti-Prune monitoring enabled.")

@antiprune.command()
@commands.has_guild_permissions(administrator=True)
async def disable(ctx):
    set_setting(ctx.guild.id,"antiprune","0")
    await ctx.reply("Anti-Prune monitoring disabled.")

# Consent-based DM centre
@bot.group(invoke_without_command=True)
@commands.guild_only()
async def dm(ctx):
    await ctx.reply("Use optin, optout, perm, revoke or send.")

@dm.command()
async def optin(ctx):
    db.execute("INSERT INTO optins VALUES(?,?,1) ON CONFLICT(guild,user) DO UPDATE SET yes=1",(ctx.guild.id,ctx.author.id))
    db.commit()
    await ctx.reply("You opted in to receive permitted Riyox DMs from this server.")

@dm.command()
async def optout(ctx):
    db.execute("INSERT INTO optins VALUES(?,?,0) ON CONFLICT(guild,user) DO UPDATE SET yes=0",(ctx.guild.id,ctx.author.id))
    db.commit()
    await ctx.reply("You opted out. Riyox will not send you these server DMs.")

@dm.command()
@commands.has_guild_permissions(administrator=True)
async def perm(ctx, member: discord.Member, amount: int, unit: str):
    days = {"day":1,"days":1,"week":7,"weeks":7,"month":30,"months":30,"year":365,"years":365}.get(unit.lower())
    if not days or not 1 <= amount <= 365:
        return await ctx.reply(f"Example: `{PREFIX}dm perm @user 2 month` (1–365).")
    expiry = int((datetime.now(timezone.utc)+timedelta(days=amount*days)).timestamp())
    db.execute("INSERT INTO dmperm VALUES(?,?,?) ON CONFLICT(guild,user) DO UPDATE SET expires=excluded.expires",
               (ctx.guild.id,member.id,expiry))
    db.commit()
    await ctx.reply(f"DM sender permission for {member.mention} expires <t:{expiry}:F>.")

@dm.command()
@commands.has_guild_permissions(administrator=True)
async def revoke(ctx, member: discord.Member):
    db.execute("DELETE FROM dmperm WHERE guild=? AND user=?",(ctx.guild.id,member.id))
    db.commit()
    await ctx.reply(f"DM sender permission revoked for {member.mention}.")

@dm.command()
async def send(ctx, member: discord.Member, *, message: str):
    row = db.execute("SELECT expires FROM dmperm WHERE guild=? AND user=?",(ctx.guild.id,ctx.author.id)).fetchone()
    allowed = is_server_owner_or_admin(ctx.author) or bool(row and row["expires"] > int(time.time()))
    if not allowed:
        return await ctx.reply("You do not have active DM sender permission.")
    opt = db.execute("SELECT yes FROM optins WHERE guild=? AND user=?",(ctx.guild.id,member.id)).fetchone()
    if not opt or opt["yes"] != 1:
        return await ctx.reply("Recipient has not opted in. They can use `&dm optin`.")
    if len(message) > 1800:
        return await ctx.reply("Message must be under 1,800 characters.")
    try:
        await member.send(embed=make_embed(ctx.guild,"Message from "+ctx.guild.name,message))
        await ctx.reply(f"Consent-based DM sent to {member.mention}.")
    except discord.Forbidden:
        await ctx.reply("DM blocked by recipient privacy settings.")

# Media forwarding
@bot.group(invoke_without_command=True)
@commands.guild_only()
async def media(ctx):
    await ctx.reply(f"Attach files to `{PREFIX}media send #channel`.")

@media.command()
@commands.has_guild_permissions(manage_messages=True)
async def send(ctx, channel: discord.TextChannel):
    if not ctx.message.attachments:
        return await ctx.reply("Attach at least one file to the command message.")
    if len(ctx.message.attachments) > 10:
        return await ctx.reply("Maximum 10 files per send.")
    try:
        files = [await a.to_file() for a in ctx.message.attachments]
        await channel.send(files=files, allowed_mentions=discord.AllowedMentions.none())
        await ctx.reply(f"Sent {len(files)} file(s) to {channel.mention}.")
    except discord.Forbidden:
        await ctx.reply("Riyox needs View Channel, Send Messages and Attach Files there.")
    except discord.HTTPException:
        await ctx.reply("Discord could not send those files.")

# Settings backup only
@bot.group(invoke_without_command=True)
@commands.guild_only()
async def backup(ctx):
    await ctx.reply(f"Use `{PREFIX}backup export`.")

@backup.command()
@commands.has_guild_permissions(administrator=True)
async def export(ctx):
    gid = ctx.guild.id
    data = {
        "guild_id": gid,
        "settings": [dict(r) for r in db.execute("SELECT key,value FROM settings WHERE guild=?",(gid,))],
        "whitelist": [r["user"] for r in db.execute("SELECT user FROM whitelist WHERE guild=?",(gid,))],
        "extraowners": [r["user"] for r in db.execute("SELECT user FROM extraowners WHERE guild=?",(gid,))],
        "dm_permissions": [dict(r) for r in db.execute("SELECT user,expires FROM dmperm WHERE guild=?",(gid,))]
    }
    file = discord.File(io.BytesIO(json.dumps(data,indent=2).encode()), filename=f"riyox-{gid}-settings.json")
    await ctx.reply("Private configuration export (not a full server backup):", file=file)

@bot.event
async def on_guild_channel_delete(channel):
    await monitor_action(channel.guild,"channel_delete",discord.AuditLogAction.channel_delete)

@bot.event
async def on_guild_role_delete(role):
    await monitor_action(role.guild,"role_delete",discord.AuditLogAction.role_delete)

@bot.event
async def on_member_ban(guild, user):
    await monitor_action(guild,"member_ban",discord.AuditLogAction.ban)

@bot.event
async def on_member_remove(member):
    guild = member.guild
    if get_setting(guild.id,"antiprune","1") != "1":
        return
    try:
        async for entry in guild.audit_logs(limit=6, action=discord.AuditLogAction.member_prune):
            if (datetime.now(timezone.utc)-entry.created_at).total_seconds() < 20:
                await send_log(guild,"🔒 Possible Member Prune",
                    f"Prune action detected by {entry.user.mention}. Discord may not expose every affected member.")
                break
    except (discord.Forbidden,discord.HTTPException):
        pass

@bot.event
async def on_voice_state_update(member, before, after):
    if member.id == bot.user.id and before.channel and after.channel is None:
        gid = member.guild.id
        if gid in voice_247 and get_setting(gid,"247","0") == "1":
            await asyncio.sleep(5)
            guild = bot.get_guild(gid)
            if guild and guild.voice_client is None:
                channel = before.channel
                try:
                    await channel.connect(timeout=20,reconnect=True)
                except Exception as ex:
                    log.warning("24/7 reconnect failed: %s", ex)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingPermissions):
        return await ctx.reply("⛔ You do not have the required Discord permission.")
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.reply(f"Missing `{error.param.name}`. Use `{PREFIX}help`.")
    if isinstance(error, commands.BadArgument):
        return await ctx.reply("Could not resolve that user/channel. Mention it and try again.")
    if isinstance(error, commands.CommandOnCooldown):
        return await ctx.reply("Please wait a moment before using that again.")
    log.exception("Command error", exc_info=error)
    try:
        await ctx.reply("Command failed. Check bot logs and permissions.")
    except discord.HTTPException:
        pass

bot.run(TOKEN)
