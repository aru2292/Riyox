# Riyox Bot

## Start on Codespaces / Linux

```bash
cp .env.example .env
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python CodeX.py
```

Before starting, add your Discord bot token to `TOKEN` in `.env`.
Set the owner ID in `OWNER_IDS` (currently configured as `499671679803457551`).

### Required Discord settings
Enable the Gateway intents required by the bot in Discord Developer Portal:
- Server Members Intent
- Message Content Intent
- Presence Intent (only if you use presence-based features)

Invite the bot with the permissions it actually needs; avoid granting Administrator unless necessary.

### Music
Music requires a reachable Lavalink node. Configure `LAVALINK_HOST`,
`LAVALINK_PASSWORD`, `LAVALINK_SECURE`, and `LAVALINK_PORT` in `.env`.
A Lavalink address is not included as a guaranteed working service.

### Dashboard
The Next.js dashboard is in `../dashboard`. It is separate from the bot process.
Use `dashboard/.env.example` as a template and configure Discord OAuth and API secrets
before deployment. The API and Cloudflare tunnel are disabled by default.

Never commit `.env`, dashboard secrets, or bot tokens.
