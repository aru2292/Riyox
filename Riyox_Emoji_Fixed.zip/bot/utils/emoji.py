# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 CodeX Devs — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://discord.gg/codexdev                      ║
# ║   youtube  ──  https://youtube.com/@CodeXDevs                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

"""
Centralized emoji module for the Riyox bot.
All emoji definitions are stored here for easy management and consistency.
"""

# ============================================================================
# DISCORD CUSTOM EMOJIS (Static)
# ============================================================================
BOOST = "🚀"
BUG_HUNTER = "🐛"
BUG_HUNTER_LVL2 = "🐛"
CAST = "📡"
CERTIFIED_MODERATOR = "🛡️"
CHANNEL = "📢"
CODEBASE = "💻"
CODED = "💻"
CROSS = "❌"
CROSS_ALT = "❌"
CUTE_CUTE_CUTE = "🥰"
DELETE = "🗑️"
DELETE_ALT1 = "🗑️"
DENIED = "🚫"
DISABLE = "🔴"
DND = "⛔"
EARLY_SUPPORTER = "🌟"
ENABLE = "🟢"
ERROR = "❌"
FORWARD = "⏩"
GAMES = "🎮"
HANDSHAKE = "🤝"
HAPPY_PANDA = "🐼"
HEADMOD = "🛡️"
HEART3 = "💜"
HEART_EM = "❤️"
HEERIYE = "🎵"
HOME = "🏠"
HYPESQUAD_BRILLIANCE = "💎"
ICONLOAD = "🔄"
ICONS_CHANNEL = "📢"
ICONS_MUSIC = "🎵"
ICONS_PAUSE = "⏸️"
ICONS_PLUS = "➕"
ICONS_WARNING = "⚠️"
ICONS_WARNING_ALT1 = "⚠️"
ICON_BROWSER = "🌐"
IDLE = "🌙"
INDEX = "📑"
INFO = "ℹ️"
KING = "👑"
LEVEL_UP = "⬆️"
LOCK = "🔒"
MANAGER = "👑"
MENTION = "📣"
MESSAGE = "💬"
MINECRAFT = "⛏️"
ML_CROSS = "❌"
MUSIC = "🎵"
MUSICSTOP_ICONS = "⏹️"
MUTE = "🔇"
NEW = "🆕"
NEXT = "⏭️"
NEXT_ALT1 = "⏭️"
OFFLINE = "⚫"
PARTNER_BADGE = "🤝"
PC = "💻"
PIN = "📌"
PREVIOUS = "⏭️"
RED_BUTTON = "🔴"
RED_PIN = "📌"
REWIND = "⏪"
REWIND_ALT1 = "⏪"
SEED = "🌱"
SHUFFLE = "🔀"
SKIP = "⏭️"
STAR = "⭐"
SWORD = "⚔️"
SYSTEM = "⚙️"
THUNDER = "⚡"
TICK = "✅"
TICKET = "🎫"
TICK_ALT = "✅"
TIME = "🕒"
TIMER = "⏱️"
UNLOCK = "🔓"
UPTIME = "⏳"
U_ADMIN = "👑"
WARNING = "⚠️"
WARNING_ALT = "⚠️"
WIFI = "📶"
ZAI = "✨"
ZARROW = "➡️"
ZBACK = "⬅️"
ZBAN = "🔨"
ZBOT = "🤖"
ZCIRCLE = "🔘"
ZCIRCLE_ALT1 = "🔘"
ZCLOUD = "☁️"
ZCOUNTING = "🔢"
ZCROSS = "❌"
ZDIL = "🧩"
ZHUMAN = "👤"
ZMODULE = "🧩"
ZMUSICPAUSE = "⏸️"
ZPAUSE = "⏸️"
ZPEOPLE = "👥"
ZPLAY = "▶️"
ZPLUS = "➕"
ZROCKET = "🚀"
ZSAFE = "🛡️"
ZSETTINGS = "⚙️"
ZTADA = "🎉"
ZTICK = "✅"
ZUNMUTE = "🔊"
ZWARNING = "⚠️"
ZWRENCH = "🔧"
ZYROXCONNECTION = "🔗"
ZYROXHAMMER = "🔨"
ZYROXLINKS = "🔗"
ZYROXSYS = "⚙️"
ZYROX_CODE = "💻"
ZYROX_COMMAND = "⌨️"
ZYROX_GLOBAL = "🌐"
ZYROX_OWNER = "👑"
ZYROX_SEARCH = "🔎"

# ============================================================================
# DISCORD CUSTOM EMOJIS (Animated)
# ============================================================================
ACTIVE_DEVELOPER = "✨"
ARROWRED = "🔻"
BLACKCROWN = "👑"
BLOBPART = "✨"
BOOSTS = "🚀"
EARLY_VERIFIED_BOT_DEV = "🧑‍💻"
EMOTE = "😄"
GIFD = "🎞️"
GIFN = "🎞️"
HYPESQUAD_BALANCE = "⚖️"
HYPESQUAD_BRAVERY = "🛡️"
HYPESQUAD_EVENTS = "🎉"
KING_ALT1 = "👑"
LOADING = "🔄"
LOADINGRED = "🔄"
LOADING_ALT1 = "🔄"
MAX__A = "🔝"
MENTION_ALT1 = "📣"
MINGLE = "💬"
MOBILE = "📱"
MUSIC_ALT1 = "🎵"
NITRO_BOOST = "🚀"
ONLINE = "🟢"
PREMIUM = "💎"
RACECAR64 = "🏎️"
REDDOT = "🔴"
REDHEART = "❤️"
REDRULESBOOK = "📕"
SG_RD = "🔴"
STAFF = "🛡️"
STAR_ALT1 = "⭐"
STAR_ALT2 = "⭐"
TADAA = "🎉"
TIMER_ALT1 = "⏱️"
_37496ALERT = "🚨"

# ============================================================================
# DISCORD BADGE EMOJIS MAPPING (Dictionary)
# ============================================================================
DISCORD_BADGE_EMOJIS = {
    "staff": STAFF,
    "partner": PARTNER_BADGE,
    "hypesquad": HYPESQUAD_BRILLIANCE,
    "hypesquad_bravery": HYPESQUAD_BRAVERY,
    "hypesquad_brilliance": HYPESQUAD_BRILLIANCE,
    "hypesquad_balance": HYPESQUAD_BALANCE,
    "bug_hunter": BUG_HUNTER,
    "bug_hunter_level_2": BUG_HUNTER_LVL2,
    "early_supporter": EARLY_SUPPORTER,
    "early_verified_bot_developer": EARLY_VERIFIED_BOT_DEV,
    "certified_moderator": CERTIFIED_MODERATOR,
    "active_developer": ACTIVE_DEVELOPER,
    "discord_mod": CERTIFIED_MODERATOR,
}

# ============================================================================
# UNICODE EMOJIS
# ============================================================================
ARROW_DOWN = "⬇️"
ARROW_LEFT = "⬅️"
ARROW_RIGHT = "➡️"
ARROW_UP = "⬆️"
BLOCK = "🚫"
BUBBLE_TEA = "🧋"
CELEBRATE = "🎉"
CHERRIES = "🍒"
CLOCK = "⏱️"
COOKIE = "🍪"
CURSOR = "🖱️"
DIZZY = "🥴"
ERROR_UNICODE = "❌"
GAME_CONTROLLER = "🎮"
HEARTS = "💕"
JAVA_COFFEE = "☕"
LAUGH1 = "😂"
LAUGH2 = "🤣"
LAUGH3 = "😆"
LOCK_UNICODE = "🔒"
MONEY = "💸"
MOON = "🌙"
NOTE = "📝"
PAPER = "\U0001f4f0"
PEACH = "🍑"
REFRESH = "🔄"
ROCK = "\U0001faa8"
SCISSORS = "\U00002702"
SHOCKED = "😳"
SPARKLE = "✨"
STAR_UNICODE = "⭐"
STOP_BUTTON = "⏹️"
SUCCESS = "✅"
TARGET = "🎯"
TONGUE_OUT = "😜"
UPSIDE_DOWN = "🙃"
WARNING_UNICODE = "⚠️"

# ============================================================================
# EMOJI COLLECTIONS BY CATEGORY (Dictionaries)
# ============================================================================
GAME_BUTTONS = {
    "up": ARROW_UP,
    "down": ARROW_DOWN,
    "left": ARROW_LEFT,
    "right": ARROW_RIGHT,
    "stop": STOP_BUTTON,
    "target": "🎯",
}

ACTION_EMOJIS = {
    "success": SUCCESS,
    "error": ERROR_UNICODE,
    "warning": WARNING_UNICODE,
    "clock": CLOCK,
    "refresh": REFRESH,
}

RPS_CHOICES = {
    "rock": ROCK,
    "scissors": SCISSORS,
    "paper": PAPER,
}

BUTTON_EMOJIS = {
    "note": NOTE,
    "privacy": LOCK_UNICODE,
    "claim": STAR_UNICODE,
    "untrust": ERROR_UNICODE,
    "block": BLOCK,
    "target": "🎯",
    "edit": "✏️",
}

REACTION_TEST_EMOJIS = [
    COOKIE, CELEBRATE, BUBBLE_TEA, CHERRIES, PEACH, MONEY, MOON, HEARTS
]

FUN_EMOJIS = [
    LAUGH1, LAUGH2, LAUGH3, SHOCKED, DIZZY, UPSIDE_DOWN, TONGUE_OUT
]

MINECRAFT_EMOJIS = {
    "success": SUCCESS,
    "error": ERROR_UNICODE,
    "warning": WARNING_UNICODE,
    "clock": CLOCK,
    "refresh": REFRESH,
    "java": JAVA_COFFEE,
}

# ============================================================================
# FEATURE EMOJIS (Dictionaries)
# ============================================================================
MODERATION_EMOJIS = {
    "warn": WARNING,
    "mute": MUTE,
    "ban": SWORD,
    "kick": SWORD,
    "lock": LOCK,
}

TICKET_EMOJIS = {
    "ticket": TICKET,
    "close": ERROR,
    "open": SUCCESS,
    "pin": PIN,
}

LEVEL_EMOJIS = {
    "level_up": LEVEL_UP,
    "sparkle": SPARKLE,
    "achievement": STAR,
}

UTILITY_EMOJIS = {
    "music": MUSIC,
    "system": SYSTEM,
    "new": NEW,
    "message": MESSAGE,
    "wifi": WIFI,
    "cast": CAST,
}

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_badge_emoji(badge_name: str) -> str:
    """
    Get Discord badge emoji by name.
    
    Args:
        badge_name: The name of the badge (e.g., 'staff', 'partner', 'bug_hunter')
    
    Returns:
        The emoji string for the badge, or None if not found
    """
    return DISCORD_BADGE_EMOJIS.get(badge_name.lower())


def get_action_emoji(action: str) -> str:
    """
    Get emoji for a common action.
    
    Args:
        action: The action name (e.g., 'success', 'error', 'warning')
    
    Returns:
        The emoji string for the action
    """
    return ACTION_EMOJIS.get(action.lower())


def get_button_emoji(button_type: str) -> str:
    """
    Get emoji for a button type.
    
    Args:
        button_type: The button type (e.g., 'note', 'privacy', 'claim')
    
    Returns:
        The emoji string for the button
    """
    return BUTTON_EMOJIS.get(button_type.lower())


# ============================================================================
# COMPATIBILITY ALIASES
# ============================================================================

# Common aliases for frequently used emojis
CHECKMARK = TICK
CROSS_MARK = CROSS
CHECK = SUCCESS
FAIL = ERROR
OK = SUCCESS
NOT_OK = ERROR

