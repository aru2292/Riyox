"""Legacy compatibility shim: Riyox uses Unicode emoji only."""

async def run_sync(token=None):
    print("💜 Riyox Unicode emoji mode enabled; custom emoji sync skipped.")
    return
