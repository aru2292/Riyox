# Riyox — Discord Bot + Dashboard

Riyox is a customized personal configuration of the supplied CodeX Devs Discord bot project.
It keeps the original MIT license and upstream attribution; see `LICENSE`.

## Included
- Discord bot with prefix and slash-command features
- Moderation, server security / anti-nuke, AutoMod and logging
- Music (requires your own working Lavalink node)
- Community, leveling, games, voice and utility commands
- Next.js dashboard with FastAPI backend integration

## Run the bot (GitHub Codespaces / Linux)

```bash
cd bot
cp .env.example .env
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python CodeX.py
```

Add your bot token privately to `bot/.env` as `TOKEN=...`.
The owner ID is currently set to `499671679803457551`. Change it in `.env` if needed.

## Dashboard
The dashboard lives in `dashboard/` and runs separately:

```bash
cd dashboard
npm install
cp .env.example .env.local
npm run dev
```

Configure Discord OAuth, API URL, matching dashboard API key, and NextAuth secret first.
For a public deployment, use HTTPS and a strong random secret.

## Important
- Never upload `.env`, `.env.local`, bot tokens, OAuth secrets, API keys, or tunnel tokens to GitHub.
- Enable only the Discord Gateway Intents the bot requires.
- Invite with the minimum permissions needed; do not grant Administrator by default.
- Music will not work until a valid Lavalink node is configured.
- The code has passed a Python syntax compilation check, but live Discord and dashboard deployment tests still need to be done.

