import logging
import time

import discord
from discord.ext import commands

import config
import keep_alive
from utils import helpers
from utils.store import Store

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("bot")

COGS = (
    "cogs.antinuke",
    "cogs.moderation",
    "cogs.automod",
    "cogs.music",
    "cogs.tempvc",
    "cogs.welcome",
    "cogs.logs",
    "cogs.utility",
    "cogs.community",
)


class AllInOneBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True  # privileged: enable in Developer Portal
        intents.message_content = True  # privileged: enable in Developer Portal
        super().__init__(
            command_prefix=commands.when_mentioned_or(config.PREFIX),
            intents=intents,
            help_command=None,
            case_insensitive=True,
            owner_ids=config.OWNER_IDS or None,
            allowed_mentions=discord.AllowedMentions(
                everyone=False, roles=False, users=True, replied_user=False
            ),
        )
        self.store = Store()
        self.started_at = time.time()

    async def setup_hook(self):
        for ext in COGS:
            try:
                await self.load_extension(ext)
                log.info("Loaded %s", ext)
            except Exception:
                log.exception("Failed to load %s", ext)

        if config.PORT:
            await keep_alive.start(config.PORT)
            log.info("Keep-alive web server on port %s", config.PORT)

        if config.AUTO_SYNC:
            try:
                synced = await self.tree.sync()
                log.info("Synced %d slash commands", len(synced))
            except discord.HTTPException:
                log.exception("Slash command sync failed")

    async def on_ready(self):
        log.info("Logged in as %s (%s) in %d servers", self.user, self.user.id, len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.listening,
                name=f"{config.PREFIX}help | /help",
            )
        )

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        original = getattr(error, "original", None)

        if isinstance(error, commands.MissingPermissions):
            text = "You need these permissions: " + ", ".join(
                p.replace("_", " ").title() for p in error.missing_permissions
            )
        elif isinstance(error, commands.BotMissingPermissions):
            text = "I'm missing these permissions: " + ", ".join(
                p.replace("_", " ").title() for p in error.missing_permissions
            )
        elif isinstance(error, commands.NoPrivateMessage):
            text = "This command only works inside a server."
        elif isinstance(error, commands.MissingRequiredArgument):
            text = (
                f"Missing argument `{error.param.name}`. "
                f"Usage: `{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}`"
            )
        elif isinstance(error, commands.CommandOnCooldown):
            text = f"Slow down! Try again in {error.retry_after:.1f}s."
        elif isinstance(error, commands.UserInputError):
            text = str(error) or "Invalid input."
        elif isinstance(error, commands.CheckFailure):
            text = str(error) or "You can't use this command."
        elif isinstance(original, discord.Forbidden):
            text = (
                "Discord refused that action. Check my permissions and make sure "
                "my role is above the target's role."
            )
        else:
            log.error("Unhandled error in command %s", ctx.command, exc_info=error)
            text = "Something went wrong. The error was logged."

        try:
            await ctx.send(embed=helpers.err(text), ephemeral=True)
        except discord.HTTPException:
            pass


def main():
    if not config.TOKEN:
        raise SystemExit(
            "DISCORD_TOKEN is missing. Copy .env.example to .env and paste your bot token in it."
        )
    bot = AllInOneBot()
    try:
        bot.run(config.TOKEN, log_handler=None)
    except discord.LoginFailure:
        raise SystemExit("Invalid token. Reset it in the Developer Portal and update your .env file.")
    except discord.PrivilegedIntentsRequired:
        raise SystemExit(
            "Turn on SERVER MEMBERS INTENT and MESSAGE CONTENT INTENT in "
            "Developer Portal -> your app -> Bot, then restart."
        )


if __name__ == "__main__":
    main()
