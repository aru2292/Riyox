"""Community tools: persistent tickets, XP levels, polls, suggestions and premium info."""
import asyncio
import random
import time

import discord
from discord.ext import commands

from utils import helpers


class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close ticket", emoji="🔒", style=discord.ButtonStyle.danger,
                       custom_id="riyox:ticket:close")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        topic = channel.topic or ""
        owner_id = None
        for part in topic.split():
            if part.startswith("riyox_ticket_owner="):
                try:
                    owner_id = int(part.split("=", 1)[1])
                except ValueError:
                    pass
        allowed = interaction.user.guild_permissions.manage_channels or interaction.user.id == owner_id
        if not allowed:
            return await interaction.response.send_message(
                "Only the ticket creator or a moderator can close this ticket.", ephemeral=True
            )
        await interaction.response.send_message("🔒 Ticket closing in 5 seconds.")
        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Ticket closed by {interaction.user}")
        except discord.HTTPException:
            pass


class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create a ticket", emoji="🎫", style=discord.ButtonStyle.primary,
                       custom_id="riyox:ticket:create")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        if guild is None:
            return await interaction.response.send_message("Use this button in a server.", ephemeral=True)
        existing = discord.utils.find(
            lambda c: c.topic and f"riyox_ticket_owner={interaction.user.id}" in c.topic,
            guild.text_channels
        )
        if existing:
            return await interaction.response.send_message(
                f"You already have an open ticket: {existing.mention}", ephemeral=True
            )
        bot_member = guild.me
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, attach_files=True
            ),
            bot_member: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, manage_channels=True
            ),
        }
        try:
            channel = await guild.create_text_channel(
                f"ticket-{interaction.user.name}".lower().replace(" ", "-")[:90],
                overwrites=overwrites,
                topic=f"Riyox support ticket riyox_ticket_owner={interaction.user.id}",
                reason="Riyox ticket panel",
            )
            await channel.send(
                f"{interaction.user.mention} Thanks for opening a ticket. Describe your issue here.",
                view=TicketCloseView(),
                allowed_mentions=discord.AllowedMentions(users=True),
            )
            await interaction.response.send_message(f"Your ticket is ready: {channel.mention}", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(
                "I need Manage Channels and Send Messages permissions to create tickets.", ephemeral=True
            )


class PremiumInfoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Music+", emoji="🎧", style=discord.ButtonStyle.secondary)
    async def music(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Music+ ideas: saved playlists, queue presets and per-server audio settings. "
            "Availability depends on future releases.", ephemeral=True
        )

    @discord.ui.button(label="Protection", emoji="🛡️", style=discord.ButtonStyle.secondary)
    async def protection(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Protection: configurable anti-nuke limits, audit logs, AutoMod and recovery alerts. "
            "Core safety tools remain free.", ephemeral=True
        )

    @discord.ui.button(label="Community", emoji="🌟", style=discord.ButtonStyle.secondary)
    async def community(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Community+: custom welcome cards, extra level roles and server profile themes. "
            "No payment is collected by this bot.", ephemeral=True
        )


class Community(commands.Cog, name="Community"):
    def __init__(self, bot):
        self.bot = bot
        self.xp_cooldowns = {}

    async def cog_load(self):
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketCloseView())

    def community_data(self, guild):
        return self.bot.store.get(guild.id)["community"]

    @commands.hybrid_command(name="ticketpanel", description="Post a persistent support ticket panel")
    @commands.guild_only()
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_guild_permissions(manage_channels=True, send_messages=True)
    async def ticket_panel(self, ctx):
        e = helpers.embed("🎫 Riyox Support", "Need help? Press the button below to open a private support ticket.")
        await ctx.send(embed=e, view=TicketPanelView())

    @commands.hybrid_command(name="rank", description="Show a member's XP rank")
    @commands.guild_only()
    async def rank(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        data = self.community_data(ctx.guild)["levels"].get(str(member.id), {"xp": 0, "level": 0})
        e = helpers.embed(f"🌟 {member.display_name}'s Rank", f"**Level:** {data.get('level', 0)}\n**XP:** {data.get('xp', 0)}")
        e.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="leaderboard", description="Show the server XP leaderboard")
    @commands.guild_only()
    async def leaderboard(self, ctx):
        levels = self.community_data(ctx.guild)["levels"]
        ranked = sorted(levels.items(), key=lambda item: (item[1].get("level", 0), item[1].get("xp", 0)), reverse=True)[:10]
        if not ranked:
            return await ctx.send(embed=helpers.embed("🏆 XP Leaderboard", "No XP data yet. Chat normally to earn XP."))
        lines = []
        for pos, (uid, data) in enumerate(ranked, 1):
            member = ctx.guild.get_member(int(uid))
            name = member.display_name if member else f"User {uid}"
            lines.append(f"**{pos}.** {name} — Level {data.get('level', 0)} · {data.get('xp', 0)} XP")
        await ctx.send(embed=helpers.embed("🏆 XP Leaderboard", "\n".join(lines)))

    @commands.hybrid_command(name="poll", description="Create a simple yes/no community poll")
    @commands.guild_only()
    @commands.cooldown(2, 30, commands.BucketType.user)
    async def poll(self, ctx, *, question: str):
        if len(question) > 240:
            return await ctx.send(embed=helpers.err("Poll question must be 240 characters or less."))
        msg = await ctx.send(embed=helpers.embed("📊 Community Poll", question))
        for emoji in ("👍", "👎"):
            try:
                await msg.add_reaction(emoji)
            except discord.HTTPException:
                break

    @commands.hybrid_command(name="suggest", description="Post a suggestion for the server")
    @commands.guild_only()
    @commands.cooldown(2, 60, commands.BucketType.user)
    async def suggest(self, ctx, *, idea: str):
        if len(idea) < 8 or len(idea) > 800:
            return await ctx.send(embed=helpers.err("Suggestion must be between 8 and 800 characters."))
        e = helpers.embed("💡 New Suggestion", idea)
        e.set_footer(text=f"Suggested by {ctx.author}", icon_url=ctx.author.display_avatar.url)
        msg = await ctx.send(embed=e)
        for emoji in ("👍", "👎"):
            try:
                await msg.add_reaction(emoji)
            except discord.HTTPException:
                break

    @commands.hybrid_command(name="premium", description="Explore Riyox premium feature categories")
    async def premium(self, ctx):
        e = helpers.embed(
            "💎 Riyox Premium",
            "Explore future feature categories below. Core moderation and server safety features stay free.\n"
            "This is an information panel only; it does not collect payments or promise an active subscription."
        )
        e.add_field(name="🎧 Music+", value="Saved playlists and queue presets", inline=True)
        e.add_field(name="🛡️ Protection", value="Advanced server protection options", inline=True)
        e.add_field(name="🌟 Community", value="Extra customization ideas", inline=True)
        await ctx.send(embed=e, view=PremiumInfoView())

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.guild is None or message.author.bot:
            return
        now = time.monotonic()
        key = (message.guild.id, message.author.id)
        if now - self.xp_cooldowns.get(key, 0) < 60:
            return
        self.xp_cooldowns[key] = now
        data = self.community_data(message.guild)["levels"]
        user = data.setdefault(str(message.author.id), {"xp": 0, "level": 0})
        user["xp"] += random.randint(8, 14)
        needed = 100 + int(user["level"]) * 50
        if user["xp"] >= needed:
            user["xp"] -= needed
            user["level"] += 1
            try:
                await message.channel.send(
                    f"🎉 {message.author.mention} reached **Level {user['level']}**!",
                    allowed_mentions=discord.AllowedMentions(users=True),
                )
            except discord.HTTPException:
                pass
        self.bot.store.save()


async def setup(bot):
    await bot.add_cog(Community(bot))
