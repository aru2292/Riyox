#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env. Add DISCORD_TOKEN before starting."
fi
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y ffmpeg
fi
python -m compileall -q main.py config.py cogs utils keep_alive.py
echo "Install and syntax check complete. Start with: python main.py"
