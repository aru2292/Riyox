"""Central configuration. Values come from environment variables or a .env file."""
import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass


def _ids(value):
    return {int(x) for x in value.replace(" ", "").split(",") if x.isdigit()}


TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("PREFIX", "&").strip() or "&"
OWNER_IDS = _ids(os.getenv("OWNER_IDS", ""))
PORT = int(os.getenv("PORT", "0") or 0)  # only needed for hosts that require an open web port
AUTO_SYNC = os.getenv("AUTO_SYNC", "1").strip().lower() not in ("0", "false", "no")
YT_COOKIES = os.getenv("YT_COOKIES", "cookies.txt").strip()  # optional, helps if YouTube blocks the host
EMBED_COLOR = 0x5865F2
